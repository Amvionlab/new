//Page Loading Function
function call_page_loading_icon(id) {
	$(id).html('<center><img src="images/loading.png" width="36" height="36"></center>');
}
function call_popup_button_submit_disable(id) {
	//popupsubmitid
	//popupsubmitidloading
	document.getElementById(id).disabled=true;	
	$("#"+id).html('<center><img src="images/loading.png" width="36" height="36"></center>');
}
function call_popup_button_submit_enable(id,displayname="Submit") {
	document.getElementById(id).disabled=false;	
	$("#"+id).html(displayname);
}
function call_search_button_submit_disable(id) {
	//popupsubmitid
	//popupsubmitidloading
	document.getElementById(id).disabled=true;	
	$("#"+id).html('<center><img src="images/loading.png" width="10" height="10"></center>');
}
function check_comm_date_format(myDate)
{
	var chunks = myDate.split('-');
	var formattedDate = chunks[1]+'-'+chunks[0]+'-'+chunks[2];
	return formattedDate;
}

function check_comm_datetime_format(myDate)
{
	var chunks = myDate.split('-');
	var formattedDate = chunks[1]+'-'+chunks[0]+'-'+chunks[2];
	return formattedDate;
}
////////////////////////////////Common Select function value
function common_select_val(str,id,err)
{
	var error="";
	if(str==0)
	{	 
		error="* Select One";
		document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	}   
	else
	{
		document.getElementById(id).className="form-group required has-success";
		document.getElementById(err).innerHTML=error;
	}
	return error;
}
function common_multiselect_val(str,id,err)
{
	var error="";
	if(str==null)
	{	 
		error="* Select One";
		document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	}   
	else
	{
		document.getElementById(id).className="form-group required has-success";
		document.getElementById(err).innerHTML=error;
	}
	return error;
}
//Commmon text Box Validation
function common_textbox_val(str,id,err)
{
	var illegalChars = /^[a-zA-Z ()*-.@#&,0-9'"_\/]+$/; 
	var error="";
    if(str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}

//Common Select function value
function common_textarea_val(str,id,err)
{
	var error="";
	if(str=="")
	{	 
		error="* Enter the value";
		document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	}   
	else
	{
		document.getElementById(id).className="form-group required has-success";
		document.getElementById(err).innerHTML=error;
	}
	return error;
}
function common_character_val(str,id,err)
{
	//var illegalChars = /^[a-zA-Z ()*-.@#&,0-9'"_\/]+$/; 
	var illegalChars = /^[a-z A-Z]*$/
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
function item_common_character_val(str,id,err)
{
	var illegalChars = /^[a-zA-Z ()-.,0-9'"_\/]+$/; 
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
function common_alpanumaric_val(str,id,err)
{
	//var illegalChars = /^[a-zA-Z ()*-.@#&,0-9'"_\/]+$/; 
	var illegalChars = /^[a-zA-Z0-9\/]+$/; 
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
function item_common_alpanumaric_val(str,id,err)
{
	//var illegalChars = /^[a-zA-Z ()*-.@#&,0-9'"_\/]+$/; 
	var illegalChars = /^[a-zA-Z0-9\/]+$/; 
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}

//Commmon text Box Validation
function common_non_textbox_val(str,id,err)
{
	var illegalChars = /^[a-zA-Z ()*-.@#&,0-9'"_\/]+$/; 
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	/*else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}*/
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
//Commmon text Box Validation
function common_integer_val(str,id,err)
{
	var illegalChars =/^[0-9]+$/;
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the number only";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
function commom_integer_non_val(str,id,err)
{
	var illegalChars =  /^[0-9]+$/;
	var error="";
	if (str=="")
    {
		document.getElementById(id).className="form-group has-success";
	    document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the number only";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
function common_decimal_non_val(str,id,err)
{
	var illegalChars = /^-{0,1}\d*\.{0,1}\d+$/;
	var error="";
	if (str=="")
    {
		document.getElementById(id).className="form-group has-success";
	    document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Only Integer Or Decimal values";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}

//Common Decimal value
function common_decimal_val(str,id,err)
{
	var illegalChars = /^-{0,1}\d*\.{0,1}\d+$/;
	var error="";
    if (str=="")
    {
		error="* This field is required .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Only Integer Or Decimal values";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
//Common Select function value
function common_date_val(str,id,err)
{
	var error="";
	if(str=="")
	{	 
		error="* Select Date";
		document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	}   
	else
	{
		document.getElementById(id).className="form-group required has-success";
		document.getElementById(err).innerHTML=error;
	}
	return error;
}
function common_datetime_val(str,id,err)
{
	var error="";
	if(str=="")
	{	 
		error="* Select Date";
		document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	}   
	else
	{
		document.getElementById(id).className="form-group required has-success";
		document.getElementById(err).innerHTML=error;
	}
	return error;
}
//Common E-mail validation
function common_email_val(str,id,err)
{
	var error="";
	var illegalChars = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (str=="")
    {
		error="* Enter the field name .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if (!illegalChars.test(str))
    {
		error="* Enter the valid name";
		document.getElementById(id).className+=" has-error";
		document.getElementById(err).innerHTML=error;
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}
	return error;
}
function commom_two_date_diff_val(date,date2,id,err,typ)
{ 
	if(typ=="report")
	{
		var msg_from="Fromdate";var msg_to="Todate";
	}
	var date1=document.getElementById(date).value;
	var error="";
    if (date1=="")
    {
		error="* Enter the field name .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	}
	else if (date2=="")
    {
		error="* Enter the field name .";
    	document.getElementById(id).className+=" has-error";
   		document.getElementById(err).innerHTML=error;
	} 
	else if(date1!="" && date2!="" )
	{
		var date_one = check_comm_datetime_format(date1);
		var date_two = check_comm_datetime_format(date2);
			//getTime() returns the number of milliseconds since 01.01.1970.
		var timeStamp_date_one = new Date(date_one); //1375077000000 
		var timeStamp_date_two = new Date(date_two);//1375080600000 
		if(timeStamp_date_one > timeStamp_date_two)
		{
			error=String(msg_to)+" should be greater than "+String(msg_from);
			document.getElementById(id).className+=" has-error";
			document.getElementById(err).innerHTML=error;
		}
		else
		{
			document.getElementById(id).className="form-group required has-success";
	    	document.getElementById(err).innerHTML=error;
		}
	}
	else
	{
		document.getElementById(id).className="form-group required has-success";
	    document.getElementById(err).innerHTML=error;
	}	
	return error;
}
//Number only type
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

//////////////////////////////////////////////
function setModalBox(content,$size)
{
  	document.getElementById('modal-content').innerHTML=content;
  	if($size == 'large')
  	{
		$('#myModal').attr('class', 'modal fade bs-example-modal-lg')
		   			 .attr('aria-labelledby','myLargeModalLabel');
		$('.modal-dialog').attr('class','modal-dialog modal-lg');
    }
    if($size == 'standart')
    {
	    $('#myModal').attr('class', 'modal fade')
		   		     .attr('aria-labelledby','myModalLabel');
	    $('.modal-dialog').attr('class','modal-dialog');
    }
    if($size == 'small')
    {
	    $('#myModal').attr('class', 'modal fade bs-example-modal-sm')
		  		     .attr('aria-labelledby','mySmallModalLabel');
	    $('.modal-dialog').attr('class','modal-dialog modal-sm');
    }
}
