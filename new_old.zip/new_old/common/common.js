var baseurl='<?php echo BASE_URL; ?>';
call_popup_computer_view=function(computers_id,view_typ){
	loadurl = baseurl+"/modules/popup/computer_view.php?computers_id="+computers_id+"&view_typ="+view_typ,
	$.get(loadurl, function(data) {
		var content=data;
		var size='large';
		setModalBox(content,size);
		$('#myModal').modal('show');
	});
}
