<?php
ini_set('display_error',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
	$pageheadtitle='SAMPAT';
    $debug=0;
	$menu_url_active=1;
    $out_query=array('');    
	
	//$config_actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$config_actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http");
	//echo $config_actual_link;
	define('BASE_URL', 'http://'.$_SERVER['HTTP_HOST'].'/sampat');
	define('MAIL_BASE_URL', $_SERVER['HTTP_HOST'].'/sampat');
	//define('BASE_URL', $config_actual_link.'://'.$_SERVER['HTTP_HOST']);//Root path
	//Database connection
	$config_sql_host = "localhost";	// SQL DataBase Server Host Name (or) IP Address
    $config_sql_user = "root";	// SQL DataBase UserName
   	$config_sql_pass = "";         //Database Password 
	//Asset Database connection
	$config_assets_sql_db_name="fullasset"; // Database name
    $config_assets_agent_sql_db_name="agent"; // Database name
    //Desk database config
	$config_desk_sql_db_name="dnc_desk"; // Database name
    $config_users_sql_db_name=$config_assets_sql_db_name; // Database name
	//Employee related dropdown list
	$config_employee_dropdown_view="name";
    
    $config_main_assets_module=true;
    $config_main_tickets_module=false;
    $config_list_page_cnt=10;//Pagnation view cnt default 
   
	$config_goback_default='<button class="btn btn-info btn-xs pull-right" onclick="javascriptt:window.history.go(-1);return false;" ><i class="glyphicon glyphicon-arrow-left"></i>&nbsp;Go&nbsp;Back</button>';
    //Dropdown default value
    $config_dropdown_common_value="Unknown";
    function get_config_dropdown_common_option($value=''){
        if($value=="0"){
            return '<option value="0" selected="selected" >Unknown</option>';
        }
        return '<option value="0">Unknown</option>';
    }
    
// for tranfer
$page_check=true;
//
$config_asset_transfer_module=true;
$config_asset_warranty_module=true;
$config_asset_amc_module=true;
$config_asset_depreciation_module=false;
$config_asset_doc_module=true;

// Access control
$config_access_control=true;
$show_tranfer=true;

// Connection // link asset
$linkcatid=24;
?>
