<?php
	require_once('../../db/sql.php');	 
	$html_1='';
	$html_2='';
	$html_3='';
	$html_4='';
	$html_5='';
	$html_6='';
	$html_7='';
	$html_1.="[";
	$html_2.="[";
	$html_3.="[";
	$html_4.="[";
	$html_5.="[";
	$html_6.="[";
	$html_7.="[";
	for($i=0; $i<=6; $i++ )
	{
		$today=date("Y-m-d");
		$date=subDayswithdate($today,$i);	
		
		/*$html_new.= '{ x: new Date(2017, 0, 30), y: 52 },';
		$html_assigned.= '{ x: new Date(2017, 0, 30), y: 52 },';
		$html_inprocess.= '{ x: new Date(2017, 0, 30), y: 52 },';
		$html_hold_pending.= '{ x: new Date(2017, 0, 30), y: 52 },';
		$html_resolved.= '{ x: new Date(2017, 0, 30), y: 52 },';
		$html_closed.= '{ x: new Date(2017, 0, 30), y: 52 },';
		$html_scheduled.= '{ x: new Date(2017, 0, 30), y: 52 },';*/	

		$sql="SELECT `statusid`, `incident_status_name`, `service_status_name`, `status_color`, `color` FROM `".$config_desk_sql_db_name."`.`ticket_status` WHERE `is_active`=1";
		$ticket_status_array=sqlquery($sql);
		while($ticket_status_data=mysqli_fetch_array($ticket_status_array))
		{
			$statusid=$ticket_status_data["statusid"];
			$sql="SELECT count(`tid`) as `tt_total` FROM `".$config_desk_sql_db_name."`.`tickets` WHERE DATE_FORMAT(ttcreatedate, '%Y-%m-%d')='".$date."' AND `status`='".$statusid."'";
			$tickets_cnt_array=sqlquery($sql);
			$tickets_cnt_data=mysqli_fetch_array($tickets_cnt_array);
			$ttcount=$tickets_cnt_data["tt_total"];
			if($statusid==1)
			{
			$html_1.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			elseif($statusid==2)
			{
			$html_2.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			elseif($statusid==3)
			{
			$html_3.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			elseif($statusid==4)
			{
			$html_4.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			elseif($statusid==5)
			{
			$html_5.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			elseif($statusid==6)
			{
			$html_6.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			elseif($statusid==7)
			{
			$html_7.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
			}
			//$html_.$statusid.= '{ x: new Date("'.$date.'"), y: '.$ttcount.' },';
		}
	}
	$html_1.= "]"; 
	$html_2.= "]"; 
	$html_3.= "]"; 
	$html_4.= "]"; 
	$html_5.= "]"; 
	$html_6.= "]"; 
	$html_7.= "]"; 
	echo $html_1.'&&&'.$html_2.'&&&'.$html_3.'&&&'.$html_4.'&&&'.$html_5.'&&&'.$html_6.'&&&'.$html_7;
?>
