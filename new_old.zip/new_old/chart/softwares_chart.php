<?php
	require_once('../db/sql.php');$search_softwares=$_REQUEST["search_softwares"];echo "[";
		 //$search_softwares="vlc";
		 $color_array=array('#3c8dbc','#00c0ef','#00a65a','#f39c12','#39CCCC','#605ca8');
		 $sql="SELECT `softwares_id` FROM `softwaresearch_map` WHERE `softwaresearch_id`='".$search_softwares."'";	
		 $softwaresearch_map_array=sqlquery($sql);
		 $sno=0;
		 while($softwaresearch_map_data=mysqli_fetch_array($softwaresearch_map_array))
		 {
			  $software_name=get_softwares_name($softwaresearch_map_data['softwares_id']);
			  $versions_id="";
			  $sql="SELECT `id` FROM `softwareversions` WHERE `softwares_id`='".$softwaresearch_map_data["softwares_id"]."'";
			  $softwareversions_array=sqlquery($sql);
			  while($softwareversions_data=mysqli_fetch_array($softwareversions_array))
			  {
				  $versions_id=$versions_id=="" ? $softwareversions_data["id"] : $versions_id.','.$softwareversions_data["id"];
			  }
			  if($versions_id<>''){
			  $sql="SELECT `c`.`id` FROM `computers_softwareversions` as `soft_ver` , `computers` as `c` WHERE (`c`.`id`=`soft_ver`.`computers_id`) AND `softwareversions_id`IN (".$versions_id.")";
			  $sql.=get_is_deleted_condi();//Deleted computers check
			  $sql.=get_is_duplicate_condi();//duplicate
			  $sql.=get_useraccess_acl_locations('`locations_id`');//Access location based
			  //echo $sql;
			  $computers_softwareversions_array=sqlquery($sql);
			  $computers_softwareversions_count=mysqli_num_rows($computers_softwareversions_array);
			  //$computers_softwareversions_count=1;
			  //echo $sub_deploy_sql;
			  $color=$color_array[$sno];
			  //echo $sub_deploy_sql;
			  if($computers_softwareversions_count!=0) {
			  	//echo '{"software": "'.$software_name.'","value": '.$computers_softwareversions_count.' },';
			  	echo '{ y: '.$computers_softwareversions_count.', label: "'.$software_name.'",name: "'.$software_name.'",id:"'.$softwaresearch_map_data["softwares_id"].'" },';
			  }
			}	  
		}
echo "]"; 
?>
