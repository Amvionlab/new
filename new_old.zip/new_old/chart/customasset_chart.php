<?php
	require_once('../db/sql.php');$search_chart_group=$_REQUEST["search_chart_group"];
	$sql_con="";
	$search_by_location=$_REQUEST["search_by_location"];
				$sql_con.=get_dontshowondashboard_condi('status_id');
				$sql_con.=get_is_deleted_condi();//Deleted computers check
				//$sql.=get_is_duplicate_condi();//duplicate
				$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
				
				if($search_by_location<>'')
				{
					$where_sql= " AND `locations_id`= '".$search_by_location."'";
				}else{
					$where_sql='';
				}
				$sql_con.=$where_sql;
	
 if($search_chart_group==0){
	echo "[";
		 //$search_softwares="vlc";
		 $color_array=array('#3c8dbc','#00c0ef','#00a65a','#f39c12','#39CCCC','#605ca8');
		 $sql="SELECT `gid`,`name` FROM `custom_cat_groups` WHERE `active`=1 and `is_deleted`=0";
		 
		 $customassetsearch_map_array=sqlquery($sql);
		 $sno=0;
		 while($customassetsearch_map_data=mysqli_fetch_array($customassetsearch_map_array))
		 {
			  $customasset_group_name=$customassetsearch_map_data['name'];
			  
			  $sql="SELECT `catid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `gid`='".$customassetsearch_map_data['gid']."'";
				$customasset_array=sqlquery($sql);
				$total=0;
				while($customasset_data=sqlarray($customasset_array))
				{
					
					// Check Table exits
					$customasset_tablename="customasset_".$customasset_data['catid'];
					
					$sql="SELECT count(`id`) as `total` FROM `".$customasset_tablename."` WHERE 1".$sql_con.";";
					$customasset_count=sqlarray(sqlquery($sql));
					$total+=($customasset_count['total']);
				}
			  if($total!=0) {
			  	echo '{ y: '.$total.', label: "'.$customasset_group_name.' ('.$total.')",name: "'.$customasset_group_name.'",id:"./customasset_cat_dashboard.php?group='.$customassetsearch_map_data["gid"].'" },';
			  }
			}	  
echo "]"; 
 }
 else
 {
	 echo "[";
		$sql="SELECT `catid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `gid`='".$search_chart_group."'";
		$customasset_array=sqlquery($sql); 
		while($customasset_data=sqlarray($customasset_array))
			{
				$sql="SELECT `mid` FROM `systemadmin_menus` where `menu_mid`=7 AND `menu_order`='".$customasset_data['catid']."'";
				$mid_value=sqlarray(sqlquery($sql));
				if(isset($mid_value['mid']) && get_acl_access_all_condi($mid_value['mid'])){
				$customasset_tablename="customasset_".$customasset_data['catid'];
				$sql="SELECT count(`id`) as `total` FROM `".$customasset_tablename."` WHERE 1".$sql_con.";";
				$customasset_count=sqlarray(sqlquery($sql));
				
					if($customasset_count['total']!=0) {
					echo '{ y: '.$customasset_count['total'].', label: "'.$customasset_data['name'].' ('.$customasset_count['total'].')",name: "'.$customasset_data['name'].'",id:"./customasset_list_dashboard.php?group='.$search_chart_group.'&cat='.$customasset_data['catid'].'"},';
					}
										
				}
			}
	echo "]";  
 }
?>
