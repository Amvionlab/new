		<header>
			<style>
				.navbar-default {
					background: #fff;
				}
				ul.navbar-right li a:hover {
					background: #518d8a !important;
					color: #FFF !important;
				}
			</style>
			
			<nav class="navbar navbar-default">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a href="http://learninfinity.info/" class="navbar-brand" style=" padding: 5px !important; margin-left: 30px !important; "> <img src="images/logo.png" class="site-logo" /></a>
					</div>
					<!-- Collection of nav links and other content for toggling -->
					<div id="navbarCollapse" class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li>
							   <a href="http://learninfinity.info/" data-close="true"> Home </a>
							</li>
							<li>
							   <a href="http://learninfinity.info/digital-e-signature-pad-with-saving-it-as-image-using-html2canvas-and-ajax-php/" data-close="true"> Back to Article </a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			
		</header>
