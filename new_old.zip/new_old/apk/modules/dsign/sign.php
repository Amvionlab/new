<div class="col-12 pt-2 pb-2" style="background-color:#F8F8F8">
<h5 class="card-title p-0 pt-3 pl-0 mb-0 pr-3 text-danger" style="text-transform:uppercase; font-size:12px"><i class="fas fa-signature"></i> Review and Put signature <i class="far fa-hand-point-down animated faa-slow faa-bounce"></i></h5>
<div id="signArea" style="border:none;" class="mt-0">
	<div class="sig sigWrapper" style="height:auto;border:none"><a href="#" class="float-right p-0 mr-1" onclick="clearme();return false;" style="font-size:11px;background-color:#fff"><i class="far fa-times-circle"></i> Clear</a>
		<div class="typed"></div>
		<canvas class="sign-pad" id="sign-pad" width="300" height="150" style="border: 0px dashed #fff;"></canvas>
	</div>
</div>
<center><button type="button" class="btn btn-info btn-sm" id="btnSaveSign"><i class="far fa-save pr-1"></i> Reviewed & Accepted</button></center>
</div>