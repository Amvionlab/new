<div class="row">
<div class="col-12 p-0">
	<div class="card assetlist-panel mb-0">
<?php if($url=='' || $url=='nodata'){ ?>
		<form class="navbar-form navbar-left" role="search" method="POST">
			<div class="col-md-12 p-1 pr-2 pl-2">
				<div class="input-group">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fas fa-tags"></i></span>
					</div>
					<input class="form-control" type="text" name="tag" placeholder="Asset Tag..." required minlength="6">
					<div class="input-group-append">
						<button class="btn btn-info" type="submit" name="search"><i class="fa fa-search"></i></button>
					</div>
				</div>
			</div>
		</form>
<?php } ?>
		<div class="card-body"></div>
	</div>
</div>
</div>
<?php
	if($url<>'' && $url<>'nodata'){	echo '<script>window.location.href ="'.BASE_URL.'/'.$url.'"</script>';	exit; }
	if($noresult){ echo '<center class="text-danger"><br>Search Tag<br><font size="4px">'.$tag.'</font></center><img src="'.BASE_URL.'/assets/img/noresult.png" style="width:50%; display: block;margin-left: auto;margin-right: auto"/>';}
?>
