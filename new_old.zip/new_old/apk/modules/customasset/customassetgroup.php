<div class="row">
<div class="col-12 p-0">
	<div class="card assetlist-panel m-0">
		<!--<div class="card-header bg-white">
			<h4 class="card-title mb-0">Asset Group</h4>
		</div>-->
		<div class="card-body">
			<ul class="contact-list">
				<?php
					$sql_con="";
					$sql_con.=get_is_deleted_condi();//Deleted check
					$sql_con.=get_dontshowondashboard_condi('status_id');
					$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
					if($search_by_location<>''){ $where_sql= " AND `locations_id`= '".$search_by_location."'"; }else{ $where_sql=''; }
					$sql_con.=$where_sql;
						
					$sql="SELECT `gid`,`name` FROM `custom_cat_groups` WHERE `active`=1 and `is_deleted`=0";
					$customgroup_array=sqlquery($sql);
					while($customgroup_data=sqlarray($customgroup_array))
					{
						$sql="SELECT `catid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `gid`='".$customgroup_data['gid']."'";
						$customasset_array=sqlquery($sql);
						$total=0;
						while($customasset_data=sqlarray($customasset_array))
						{
							
							// Check Table exits
							$customasset_tablename="customasset_".$customasset_data['catid'];
							$is_table_exits = sqlquery('select 1 from `'.$customasset_tablename.'` LIMIT 1');
							if($is_table_exits == FALSE)
							{
								sqlquery("CREATE TABLE `".$customasset_tablename."` LIKE `customasset_catid`;");
							}
							$sql="SELECT count(`id`) as `total` FROM `".$customasset_tablename."` WHERE 1".$sql_con.";";
							$customasset_count=sqlarray(sqlquery($sql));
							
							$_SESSION[$customasset_tablename."_search_by_location"]=$search_by_location;
							
							$total+=($customasset_count['total']);
						}
						$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/gid_'.$customgroup_data['gid'].'.png';
						if($total>0)
						{
						echo '<li>
								<a href="'.BASE_URL.'/customassetsubgroup.php?gid='.$customgroup_data['gid'].'" title="'.$customgroup_data['name'].'">
								<div class="contact-cont">
									<div class="float-left user-img m-r-10">
										<img src="'.$icon_path.'" alt="" class="w-40 rounded" style="max-height:55px;max-width:55px;min-width:auto;">
									</div>
									<div class="row contact-info p-0">
										<div class="col-10 p-0">
										<span class="contact-name text-ellipsis">'.$customgroup_data['name'].'</span>
										<span class="contact-date text-danger">'.$total.'</span>
										</div><div class="col-2 pt-2">
										<span class="contact-view text-info " style="font-size:12px"><i class="fas fa-chevron-right"></i><i class="fas fa-chevron-right"></i></span>
										</div>
									</div>
								</div>
								</a>
							</li>';
						}
							
					}
				?>
			</ul>
		</div>
		<!--
		<div class="card-footer text-center bg-white">
			<a href="doctors.html" class="text-muted">loading...</a>
		</div>
		-->
	</div>
</div>
</div>