<div class="row">
<div class="col-12 p-0">
	<div class="card assetlist-panel m-0">
		<!--<div class="card-header bg-white">
			<h4 class="card-title mb-0">Asset Group</h4>
		</div>-->
		<div class="card-body">
			<ul class="contact-list" id="asset-list">
				<?php
					$customasset_tablename="customasset_".$catid;
					$config_list_page_cnt=10;
					$sql_con= 1;
					$sql_con.=get_is_deleted_condi();//Deleted computers check
					$sql_con.=get_dontshowondashboard_condi('status_id');
					$sql_con.=get_is_duplicate_condi();//duplicate
					$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
					if($search_by_location<>''){ $where_sql= " AND `locations_id`= '".$search_by_location."'"; }else{ $where_sql=''; }
					$sql_con.=$where_sql;
					
					$icon_path=$base_dir.'/../img/customasset/'.$catid.'.png';
					if(!file_exists($icon_path))
					{
						$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/0.png';
					}
					else{
						$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/'.$catid.'.png';
					}
					
					$sql="SELECT `catempid`, `field_name`, `field_type`, `field_length`, `active`, `is_deleted`, `created_date`, `is_default` FROM `custom_asset_templates` WHERE `catid`='".$catid."' AND `is_default`=0 AND `active`=1";
					$customassettemp_array=sqlquery($sql);
					$custom_query_insert="";
					//echo $sql;
					while($customassettemp_data=sqlarray($customassettemp_array))
					{
						$fieldname="field".$customassettemp_data['catempid'];
						$col_exits = sqlquery("select `".$fieldname."` from `".$customasset_tablename."` LIMIT 1");
						if($col_exits){
							$custom_query_insert.=", `".$fieldname."`";
						}
						
					}
					
					$sql="SELECT `id`, `name`, `tag`, `comment`, `serial`, `otherserial`, `locations_id`, `type_id`, `model_id`, `manufacturers_id`, `default_1`, `default_2`, `is_deleted`, `employee_id`, `status_id`, `substatus_id`, `date_creation`, `created_login`, `is_update_type`, `add_type`, `date_mod`, `mod_login`, `is_allocated`, `is_duplicate` ".$custom_query_insert." FROM `".$customasset_tablename."` WHERE ".$sql_con;
					$customassets_array=sqlquery($sql);
					$total_count = sqlnumrow($customassets_array);
					
					$html='<input type="hidden" name="gid" id="gid" value="'.$gid.'" /><input type="hidden" name="catid" id="catid" value="'.$catid.'" /><input type="hidden" name="total_count" id="total_count" value="'.$total_count.'" />';
						
					$sql=$sql." ORDER BY `id` LIMIT ".$config_list_page_cnt ;
					
					$customasset_array=sqlquery($sql);
					
					while($customasset_data=sqlarray($customasset_array))
					{
						$img='';
						$sql="SELECT `attachment_id`, `asset_tablename`, `asset_id`, `attachmentname`, `path`, `filetype`, `filesize`, `is_assetimage`, `is_view` FROM `asset_documents` WHERE `asset_tablename`='".$customasset_tablename."' AND `asset_id`='".$customasset_data["id"]."' AND `is_assetimage`=1";
						$image_array=sqlquery($sql);
						while($image_data=sqlarray($image_array)){
							$img_type=array('jpg','jpeg','png','gif');
							$img_src_path=$base_dir."/../".$image_data['path'];
							$path_info = pathinfo($img_src_path);
							$file_type=$path_info['extension'];
							if($image_data["is_assetimage"]==1 && in_array($file_type, $img_type))
							{
								$img=ASSET_IMG_BASE_URL.'/'.$image_data['path'];
							}
						}
						if($img==''){$img=$icon_path;}
						$tag=$customasset_data['tag'];
						echo '<li class="asset-item" id="'.$customasset_data["id"].'">
								<a href="'.BASE_URL.'/viewasset.php?gid='.$gid.'&catid='.$catid.'&id='.$customasset_data["id"].'" title="'.$customasset_data['name'].'">
								<div class="contact-cont">
									<div class="float-left user-img m-r-10">
										<img src="'.$img.'" alt="" class="w-40 rounded" style="max-height:55px;max-width:55px;min-width:auto;">
									</div>
									<div class="row contact-info p-0">
										<div class="col-10 p-0">
										<span class="contact-name text-ellipsis">'.$customasset_data['name'].'</span>
										<span class="contact-date text-danger">'.$customasset_data["serial"].'</span><br>
										<span class="contact-date text-success">'.strtoupper($tag).'</span><br>
										<span class="contact-date">'.call_custom_asset_manufacturers_name($customasset_data["manufacturers_id"]).' | '.call_custom_asset_model_name($customasset_data["model_id"]).'</span>
										</div><div class="col-2 pt-2">
										<span class="contact-view text-info " style="font-size:12px"><i class="fas fa-chevron-right"></i><i class="fas fa-chevron-right"></i></span>
										</div>
									</div>
								</div>
								</a>
							</li>';
						
					}
				?>
			</ul>
		</div>
		<?php 
		$html.='<div class="box-body">
					<div class="box-footer clearfix" style="border:none;">
						<div class="ajax-loader text-center">
							<img src="assets/img/loading.png" style="width:25px"> Loading more asset...
						</div>
					</div>
				</div>';
		echo $html;?>
		<!--
		<div class="card-footer text-center bg-white">
			<a href="doctors.html" class="text-muted">loading...</a>
		</div>
		-->
	</div>
</div>
</div>