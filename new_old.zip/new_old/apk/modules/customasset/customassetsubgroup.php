<div class="row">
<div class="col-12 p-0">
	<div class="card assetlist-panel m-0">
		<!--<div class="card-header bg-white">
			<h4 class="card-title mb-0">Asset Group</h4>
		</div>-->
		<div class="card-body">
			<ul class="contact-list">
				<?php
					$sql="SELECT `gid`,`name` FROM `custom_cat_groups` WHERE `gid`='".$gid."'";
					$group_data=sqlarray(sqlquery($sql));

					$sql_con="";
					$sql_con.=get_is_deleted_condi();//Deleted check
					$sql_con.=get_dontshowondashboard_condi('status_id');
					$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
					if($search_by_location<>''){ $where_sql= " AND `locations_id`= '".$search_by_location."'"; }else{ $where_sql=''; }
					$sql_con.=$where_sql;
					
					$sql="SELECT `catid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `gid`='".$group_data['gid']."'";
					$customasset_array=sqlquery($sql);
					
					while($customasset_data=sqlarray($customasset_array))
					{
						$sql="SELECT `mid` FROM `systemadmin_menus` where `menu_mid`=7 AND `menu_order`='".$customasset_data['catid']."'";
						$mid_value=sqlarray(sqlquery($sql));
						if(isset($mid_value['mid']) && get_acl_access_all_condi($mid_value['mid'])){
							
							$icon_path=$base_dir.'/../img/customasset/'.$customasset_data['catid'].'.png';
							
							if(!file_exists($icon_path))
							{
								$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/0.png';
							}
							else{
								$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/'.$customasset_data['catid'].'.png';
							}
							// Check Table exits
							$customasset_tablename="customasset_".$customasset_data['catid'];
							$is_table_exits = sqlquery('select 1 from `'.$customasset_tablename.'` LIMIT 1');
							if($is_table_exits == FALSE){sqlquery("CREATE TABLE `".$customasset_tablename."` LIKE `customasset_catid`;");}
							
							$sql="SELECT count(`id`) as `total` FROM `".$customasset_tablename."` WHERE 1".$sql_con.";";
							$customasset_count=sqlarray(sqlquery($sql));	
							if($customasset_count['total']>0)
							{
							echo '<li>
									<a href="'.BASE_URL.'/customassetlist.php?gid='.$gid.'&catid='.$customasset_data['catid'].'" title="'.$customasset_data['name'].'">
									<div class="contact-cont">
										<div class="float-left user-img m-r-10">
											<img src="'.$icon_path.'" alt="" class="w-40 rounded" style="max-height:55px;max-width:55px;min-width:auto;">
										</div>
										<div class="row contact-info p-0">
											<div class="col-10 p-0">
											<span class="contact-name text-ellipsis">'.$customasset_data['name'].'</span>
											<span class="contact-date text-danger">'.$customasset_count['total'].'</span>
											</div><div class="col-2 pt-2">
											<span class="contact-view text-info " style="font-size:12px"><i class="fas fa-chevron-right"></i><i class="fas fa-chevron-right"></i></span>
											</div>
										</div>
									</div>
									</a>
								</li>';
							}
						}
					}
				?>
			</ul>
		</div>
		<!--
		<div class="card-footer text-center bg-white">
			<a href="doctors.html" class="text-muted">loading...</a>
		</div>
		-->
	</div>
</div>
</div>