<?php 
$sql="SELECT `gid`,`name` FROM `custom_cat_groups` WHERE `gid`='".$gid."'";
$group_data=sqlarray(sqlquery($sql));
$sql="SELECT  `name` FROM `custom_asset_types` WHERE `catid`='".$catid."' and `gid`='".$gid."'";
$asset_type_name=sqlarray(sqlquery($sql));

$customasset_tablename="customasset_".$catid;

$sql="SELECT * FROM `".$customasset_tablename."` WHERE `id`='".$id."'";
$assets_array=sqlquery($sql);
$assets_data=sqlarray($assets_array);

$name=$assets_data["name"];
$tag=$assets_data["tag"];
$types=call_custom_asset_type_name($assets_data["type_id"]);
$serial=$assets_data["serial"];
$manufacturer=call_custom_asset_manufacturers_name($assets_data["manufacturers_id"]);
$model=call_custom_asset_model_name($assets_data["model_id"]);
$assets_status=get_assets_status_name($assets_data["status_id"]);
$assets_substatus=get_assets_substatus_name($assets_data["substatus_id"]);
$location=get_locations_name($assets_data["locations_id"]);
$office_ctl=$assets_data['default_1'];
$sapid=$assets_data["otherserial"];
$sapvalue=$assets_data["default_2"];
$pdate=$assets_data["default_3"];
$create=$assets_data["date_creation"];

// For image
$icon_path=$base_dir.'/../img/customasset/'.$catid.'.png';
if(!file_exists($icon_path))
{
	$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/0.png';
}
else{
	$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/'.$catid.'.png';
}
		
// For gallery
$sql="SELECT `attachment_id`, `asset_tablename`, `asset_id`, `attachmentname`, `path`, `filetype`, `filesize`, `is_assetimage`, `is_view` FROM `asset_documents` WHERE `asset_tablename`='".$customasset_tablename."' AND `asset_id`='".$assets_data["id"]."' AND `is_assetimage`=1";
$image_array=sqlquery($sql);
$img_gal_html=$img=$img_src_path='';
while($image_data=sqlarray($image_array)){
	$img_type=array('jpg','jpeg','png','gif');
	$img_src_path=$base_dir."/../".$image_data['path'];
	if(file_exists($img_src_path))
	{
		$path_info = pathinfo($img_src_path);
		$filedate=filemtime($img_src_path);
		$file_type=$path_info['extension'];
		if (in_array($file_type, $img_type)) {
			if($img==''){
				$img=ASSET_IMG_BASE_URL.'/'.$image_data['path']; // For Page top Title image
			}
		$img_gal_html.='<div class="col-4 m-b-20"><a href="'.ASSET_IMG_BASE_URL.'/'.$image_data['path'].'" onclick="return false;" data-sub-html="File Name: '.$image_data['attachmentname'].' <br> File Size: '.filesizeconverter($image_data['filesize']).' <br> Upload On: '.date("F d Y H:i:s", $filedate).'"><img class="img-thumbnail" src="'.ASSET_IMG_BASE_URL.'/'.$image_data['path'].'" alt="'.$image_data['attachmentname'].'"></a></div>';
		}
	}
}
if($img==''){$img=$icon_path;}
/// ./End Image gallery ///

$employee_id=$assets_data["employee_id"];
$allocated_map=get_employees_name($employee_id);
if(!$assets_data["is_allocated"])
{
  $allocated_map='Not Allocated';
}

$mod=$assets_data['date_mod'];
if($mod==''){$mod=$assets_data['date_creation'];}
$asset_update_date='&nbsp;<i class="far fa-calendar-check pl-2 pr-1"></i>'.date("H:i:s, d M Y",strtotime($mod));
?>
<div class="row">
	<div class="col-sm-12 p-0">
		<div class="card-box profile-header">
			<div class="row">
				<div class="col-md-12">
				 
					<div class="profile-view">					
						<div class="profile-img-full p-0">
							<a href="#" class=""><center><img class="img-thumbnail" style="border:none;" src="<?php echo $img;?>" alt=""></center></a>
						</div>
						<?php echo '
						<div class="profile-basic">
							<div class="row">
								<div class="col-10">
									<div class="" style="border-right: 1px dashed #ccc;">
										<h2 class="text-left"><a class="avatar profilenameicon bg-warning fa-shadow" href="">'.$allocated_map.'</a><span class="fa-shadow text-info" style="">'.$allocated_map.'</span><br><small style="font-size:15px;">'.$asset_update_date.'</small></h2>
									</div>
								</div>
								<div class="col-2 p-0">
									<a href="chat.html" class="fa-shadow" style="font-size:20px;"><i class="fa fa-camera pl-2"></i></a><br>
									<a href="" class="fa-shadow" style="font-size:20px;" id="zoom-btn" onclick="return false;"><i class="far fa-images pl-2"></i></a>
								</div>
								<div class="col-md-12">
								<div class="profile-info-left pt-0"></div>
									<ul class="personal-info">
										<li>
											<span class="title">Name</span>
											<span class="text">'.$name.'</span>
										</li>
										<li>
											<span class="title">Tag</span>
											<span class="text">'.$tag.'</span>
										</li>
										<li>
											<span class="title">Serial Number</span>
											<span class="text">'.$serial.'</span>
										</li>
										<li>
											<span class="title">Manufacturer</span>
											<span class="text">'.$manufacturer.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Model</span>
											<span class="text">'.$model.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Location</span>
											<span class="text">'.$location.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Office/CTI</span>
											<span class="text">'.$office_ctl.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Status</span>
											<span class="text">'.$assets_status.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Sub-Status</span>
											<span class="text">'.$assets_substatus.'&nbsp;</span>
										</li>
										<li>
											<span class="title">SAP ID</span>
											<span class="text">'.$sapid.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Value</span>
											<span class="text">'.$sapvalue.'&nbsp;</span>
										</li>
										<li>
											<span class="title">Purchase Date</span>
											<span class="text">'.$pdate.'&nbsp;</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
						';
						// For image gallery
						
						echo '<div class="profile-info-left pt-0"></div>
							<div class="profile-basic">
								<h2 class="text-left pb-2"><a class="avatar bg-warning fa-shadow" href=""><i class="far fa-images"></i></a><span class="fa-shadow text-info" style="">Asset Gallery</span></h2>
								<div id="lightgallery" class="row">'.$img_gal_html.'</div>
							</div>
						';
						?>
					</div>                        
				</div>
			</div>
		</div>
	</div>
</div>