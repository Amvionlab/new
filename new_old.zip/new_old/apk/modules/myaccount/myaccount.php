<?php 
$view_emp_id=$userid;
$sql="SELECT * FROM `appuser` WHERE `id`='".$view_emp_id."'";
$appuser_array=sqlquery($sql);
$appuser_data=sqlarray($appuser_array);
$emp_id=$appuser_data['employeeid'];
$user_img_path=$base_dir.'/../userimg/'.$emp_id.'.jpg';
if(!file_exists($user_img_path))
{
	$user_img_path=ASSET_IMG_BASE_URL.'/userimg/0.png';
}
else{
	$user_img_path=ASSET_IMG_BASE_URL.'/userimg/'.$emp_id.'.jpg';
}
	
$sql="SELECT `id`, `name` FROM `locations` WHERE `id`='".$appuser_data["l"]."'";
$sql_location_array=sqlquery($sql);
$sql_location_data=sqlarray($sql_location_array);
//<i class="far fa-id-card"></i>
$mytitle='&nbsp;<i class="far fa-id-card pl-2 pr-1"></i>'.$appuser_data["title"];

?>
<div class="row">
	<div class="col-sm-12 p-0">
		<div class="card-box profile-header">
			<div class="row">
				<div class="col-md-12">
				 
					<div class="profile-view">					
						<div class="profile-img-full p-0">
							<a href="#" class=""><center><img class="img-thumbnail" style="border:none;" src="<?php echo $user_img_path;?>" alt=""></center></a>
						</div>
						<?php echo '
						<div class="profile-basic">
							<div class="row">
								<div class="col-10">
									<div class="" style="border-right: 1px dashed #ccc;">
										<h2 class="text-left"><a class="avatar profilenameicon bg-warning fa-shadow" href="">'.$appuser_data["givenname"].'</a><span class="fa-shadow text-info" style="">'.$appuser_data["givenname"].'</span><br><small style="font-size:15px;">'.$mytitle.'</small></h2>
									</div>
								</div>
								<div class="col-2 p-0">
									<a href="chat.html" class="fa-shadow" style="font-size:20px;"><i class="fa fa-camera pl-2"></i></a><br>
									<!--<a href="" class="fa-shadow" style="font-size:20px;" id="zoom-btn" onclick="return false;"><i class="far fa-images pl-2"></i></a>-->
								</div>
								<div class="col-md-12">
								<div class="profile-info-left pt-0"></div>
									<ul class="personal-info">
										<li>
											<span class="title">User Name</span>
											<span class="text">'.$appuser_data["samaccountname"].'</span>
										</li>
										<li>
											<span class="title">Emoloyee ID</span>
											<span class="text">'.$appuser_data["employeeid"].'</span>
										</li>
										<li>
											<span class="title">Name</span>
											<span class="text">'.$appuser_data["givenname"].'</span>
										</li>
										<li>
											<span class="title">Gender</span>
											<span class="text">'.get_gender_name($appuser_data["gender"]).'&nbsp;</span>
										</li>
										<li>
											<span class="title">Designation</span>
											<span class="text">'.$appuser_data["title"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Department</span>
											<span class="text">'.$appuser_data["department"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Mobile</span>
											<span class="text">'.$appuser_data["mobile"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Email</span>
											<span class="text">'.$appuser_data["mail"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Extention</span>
											<span class="text">'.$appuser_data["extention_no"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Country</span>
											<span class="text">'.$appuser_data["co"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">State</span>
											<span class="text">'.$appuser_data["st"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Location</span>
											<span class="text">'.$sql_location_data["name"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Building</span>
											<span class="text">'.$appuser_data["building"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Block</span>
											<span class="text">'.$appuser_data["block"].'&nbsp;</span>
										</li>
										<li>
											<span class="title">Floor</span>
											<span class="text">'.$appuser_data["floor"].'&nbsp;</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
						';
						// For image gallery
						/*
						echo '<div class="profile-info-left pt-0"></div>
							<div class="profile-basic">
								<h2 class="text-left pb-2"><a class="avatar bg-warning fa-shadow" href=""><i class="far fa-images"></i></a><span class="fa-shadow text-info" style="">Asset Gallery</span></h2>
								<div id="lightgallery" class="row">'.$img_gal_html.'</div>
							</div>
						';
						*/
						?>
					</div>                        
				</div>
			</div>
		</div>
	</div>
</div>