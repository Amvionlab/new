<div class="row pb-0 mb-0">
	<div class="col-12 p-0">
		<div class="card assetlist-panel mb-0">
			<?php if($url=='' || $url=='nodata'){ ?>
			<div class="row p-1 pt-2 pb-2" style="border-bottom: 1px dashed #ccc;">
					<div class="col-8 pr-0">
					<form class="navbar-form navbar-left" role="search" method="POST">
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text"><i class="fas fa-tags"></i></span>
							</div>
							<input class="form-control" type="text" name="tag" placeholder="Asset Tag..." required minlength="6">
							<div class="input-group-append">
								<button class="btn btn-info" type="submit" name="search"><i class="fa fa-search"></i></button>
							</div>
						</div>
						</form>
					</div>
				<div class="col-4 pl-1">
				<a href="tagsearch.php" onclick="call_scanner();return false;" ><button class="btn btn-warning col-12 text-white" type="submit" name="search" style="font-size:17px"><i class="fas fa-barcode"></i> &nbsp;Scan</button></a>
				</div>
			</div>
			<?php } if($url==''){?>
			<div class="card-body">
			
				
									  
					<div class="contents">
						<div id="readytoout">
							<?php include_once("transfer_ready_to_in.php");?>
						</div>
					</div>
				
			
			</div>
			<?php
			}
			if($url<>'' && $url<>'nodata'){	echo '<script>window.location.href ="'.BASE_URL.'/'.$url.'"</script>';	exit; }
			if($noresult){ echo '<center class="text-danger"><br><h3>Search Tag</h3><font size="6px" style="text-transform: uppercase;">'.$tag.'</font></center><img src="'.BASE_URL.'/assets/img/noresult.png" style="width:50%; display: block;margin-left: auto;margin-right: auto"/><br><a class="btn btn-info" href="." onclick="window.history.back();return false;"><i class="fas fa-arrow-left"></i> Back</a>';}
			?>
		</div>
	</div>

</div>