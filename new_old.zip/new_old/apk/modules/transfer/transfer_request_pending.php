<?php
$scanned_list_html='';
$hrml_summary='';
$sql_where="`transfer_by`='".$userid."' AND `status`=3 AND `is_active`=1";
$sql="SELECT `atid`, `transfer_date`, `received_date`, `transfer_by`, `approved_by`, `approved_date`, `is_active`, `aid` as `asset_id`, `asset_table`, `status`, `received_by`, `transfer_note`, `approval_note`, `transfer_to`, `transfer_from`, `out_by`, `out_date`, `approved_view`, `reject_view`, `approved_view_date`, `reject_view_date`, `requested_date` FROM `asset_transfer` WHERE ".$sql_where." ORDER BY `atid` DESC;";
$transfer_array=sqlquery($sql);
$datacount=sqlnumrow($transfer_array);
if($datacount>0)
{
	while($transfer_data=sqlarray($transfer_array))
	{
		// url for asset ////////
		$asset_url='#';
		$catid=0;
		if(isset($transfer_data['asset_table']) && $transfer_data['asset_table']<>'')
		{
			
			$sql="SELECT `custom_asset_id`,`db_table_name` FROM `assettag_config` WHERE `db_table_name`='".$transfer_data['asset_table']."' LIMIT 1;";
			$tablename_array=sqlarray(sqlquery($sql));
			if(isset($tablename_array['db_table_name']))
			{
				$tablename=$tablename_array['db_table_name'];
				// Need to find gid,catid,id
				$sql="SELECT * FROM `".$tablename."` WHERE `id`='".$transfer_data['asset_id']."' ";
				$sql.=get_is_deleted_condi();//Deleted computers check
				//$sql.=get_useraccess_acl_locations('`locations_id`');//Access location based
				$sql.=" LIMIT 1;";	
				$id_array=sqlquery($sql);
				$count=sqlnumrow($id_array);
				if($count==1)
				{
					$asset_id=sqlarray($id_array);
					// Find gid & catid using `custom_asset_id` from `assettag_config`
					$sql="SELECT `catid`, `gid` FROM `custom_asset_types` WHERE `catid`='".$tablename_array['custom_asset_id']."' LIMIT 1;";
					$refid=sqlarray(sqlquery($sql));
					$asset_url="viewasset.php?gid=".$refid['gid']."&catid=".$refid['catid']."&id=".$asset_id['id'];
					$catid=$refid['catid'];
				}
				else{
					//$noresult=true;
				}
			}
			else{
				//$noresult=true;
			}
		}
		/// Cat image
		$icon_path=$base_dir.'/../img/customasset/'.$catid.'.png';
		$customasset_tablename="customasset_".$catid;
		if(!file_exists($icon_path))
		{
			$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/0.png';
		}
		else{
			$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/'.$catid.'.png';
		}
		// Asset image
		$img='';
		$sql="SELECT `attachment_id`, `asset_tablename`, `asset_id`, `attachmentname`, `path`, `filetype`, `filesize`, `is_assetimage`, `is_view` FROM `asset_documents` WHERE `asset_tablename`='".$customasset_tablename."' AND `asset_id`='".$transfer_data["asset_id"]."' AND `is_assetimage`=1";
		$image_array=sqlquery($sql);
		while($image_data=sqlarray($image_array)){
			$img_type=array('jpg','jpeg','png','gif');
			$img_src_path=$base_dir."/../".$image_data['path'];
			$path_info = pathinfo($img_src_path);
			$file_type=$path_info['extension'];
			if($image_data["is_assetimage"]==1 && in_array($file_type, $img_type))
			{
				$img=ASSET_IMG_BASE_URL.'/'.$image_data['path'];
			}
		}
		if($img==''){$img=$icon_path;}
		/////////////////////////
		// Check for Error msg
		$verified_html='<span class="contact-view text-red text-center pt-2 mt-1"><i class="far fa-clock" style="font-size:22px"></i><br>Pending</span>';
		$verified_status_html='<br><font style="font-size:12px;color:green;"><i class="far fa-thumbs-up m-r-2"></i> Approved</font>';
		if(isset($audit_asset_list['is_error']) && $audit_asset_list['is_error']==1)
		{
			$verified_html='<span class="contact-view text-info pt-2 mt-1"><i class="far fa-thumbs-down text-danger" style="font-size:22px"></i><br>Rejected</span>';
			$verified_status_html='<br><font style="font-size:12px;color:red;"><i class="far fa-thumbs-down m-r-2"></i> '.$audit_asset_list['error_hint'].'</font>';
		}
		/////////////////////
		$scanned_list_html.='<li class="asset-item p-2" id="'.$asset_id["id"].'">
							<a href="'.BASE_URL.'/'.$asset_url.'" title="'.$asset_id['name'].'">
							<div class="contact-cont">
								<div class="float-left user-img m-r-10">
									<img src="'.$img.'" alt="" class="w-40 rounded" style="max-height:55px;max-width:55px;min-width:auto;">
								</div>
								<div class="row contact-info p-0">
									<div class="col-10 p-0">
									<span class="contact-name text-ellipsis">'.$asset_id['name'].'</span>
									<span class="contact-date text-danger">'.$asset_id["serial"].'</span> | 
									<span class="contact-date text-success">'.strtoupper($asset_id['tag']).'</span><br>
									<span class="contact-date">'.call_custom_asset_manufacturers_name($asset_id["manufacturers_id"]).' | '.call_custom_asset_model_name($asset_id["model_id"]).'</span><br>
									<span class="contact-date"><i class="fas fa-route text-info"></i> '.get_locations_name($transfer_data['transfer_from']).'&nbsp;<font style="color:#EB0000;">&#10132;</font>&nbsp;'.get_locations_name($transfer_data['transfer_to']).'</span>
									<!--'.$verified_status_html.'-->
									</div>
									<div class="col-2 pt-2">'.$verified_html.'</div>
								</div>
							</div>
							</a>
						</li>';
		
	}
}
else{
	$hrml_summary=nodatafound(70);
}
// For summry
$overall_asset_count=0;
$total_scanned=$total_scanned=0;
$total_pending=$overall_asset_count-$total_scanned;
$total_error=$total_error=0;
//$hrml_summary='';
/*
$hrml_summary.= '<div class="row p-0 pb-0">
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border: 1px dashed #ccc;">
							Scanned
							<h4 class="text-info">'.$total_scanned.'</h4>
						</div>
					</div>
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border-top: 1px dashed #ccc;border-bottom: 1px dashed #ccc;">
							Pending
							<h4 class="text-warning">'.$total_pending.'</h4>
						</div>
					</div>
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border: 1px dashed #ccc;">
							Error
							<h4 class="text-danger">'.$total_error.'</h4>
						</div>
					</div>
				</div>';
*/
echo '
		<div class="col-12 p-0 m-0">
			<div class="card assetlist-panel m-0">
				<h3 class="card-title pt-4 pl-3 pb-3 pr-3 text-left" style="text-transform:uppercase;border-bottom: 1px dashed #ccc;"><i class="fas fa-clock"></i>&nbsp Request list (Waiting for approval)</small>
					<!--<span class="badge badge-pill bg-danger float-right"><a href="#" onclick="call_auditscanner();return false;" style="color:#fff"><i class="fas fa-camera m-r-5"></i> Start Scan</a></span>--></h3>
				'.$hrml_summary.'
				<div class="card-body">
					<ul class="contact-list" id="asset-list">
						'.$scanned_list_html.'
					</ul>
				</div>
			</div>
		</div>
	';
?>