<div class="row">
<?php
function readMore_txt($story_desc, $pos = 100,$auditid) {
	if(strlen($story_desc)>$pos){
		$str_to_insert='<span id="dots_'.$auditid.'"></span><span id="readmore_'.$auditid.'" onclick="readmore_txt('.$auditid.');return false;" style="display: none;">';
		$story_desc = substr($story_desc, 0, $pos) . $str_to_insert . substr($story_desc, $pos);
		$story_desc = $story_desc.'</span> <a href="#" onclick="readmore_txt('.$auditid.');return false;" id="readMoreBtn_'.$auditid.'">... more</a>';
	}		
	return $story_desc;  
} 

	$audit_status=array('-','On-Going','Not Started','Completed');
	$audit_status_color=array('bg-danger text-white','bg-warning text-white','bg-info text-white','bg-success text-white');
	$sql="SELECT `auditid`, `name`, `comments`, `location_id`, `userid`, `created_date`, `status`,`start_date`, `end_date`, `is_active`, `is_deleted` FROM `audit` WHERE `userid`='".$_SESSION["login_eid"]."'";
	$where=get_useraccess_acl_locations('`location_id`');//Access location based
	$where.=get_is_deleted_condi();//Deleted computers check
	$sql=$sql.$where;
	$sql=$sql." ORDER BY `status`;";
	
	$audit_array=sqlquery($sql);
	$auditcount=sqlnumrow($audit_array);
	
	if($auditcount==0)
	{
		echo nodatafound(70);
	}
	else{
		$show_start_button=true;
		while($audit=sqlarray($audit_array))
		{
			//2-not start, 1-started, 3-completed
			$i=$audit['status'];
			$bgclass='bg-black ';
			if($i==1){$bgclass='bg-orange ';}
			elseif($i==2){$bgclass='bg-white ';}
			$audit_menu='';
			if($i==1 || $i==3){ 
				$audit_menu.='<a class="dropdown-item" href="auditview.php?aid='.$audit['auditid'].'"><i class="fas fa-sitemap m-r-5"></i> View</a>';
				$show_start_button=false;
			}
			if($i==2 && $show_start_button){ 
				$audit_menu.='<a class="dropdown-item" href="auditscan.php?aid='.$audit['auditid'].'"><i class="fas fa-barcode m-r-5"></i> Start Audit</a>';
			}
			if($i==1){
				$audit_menu.='<a class="dropdown-item" href="auditscan.php?aid='.$audit['auditid'].'"><i class="fas fa-barcode m-r-5"></i> Resume Audit</a>';
			}
			
			$audit_menu.='<a class="dropdown-item" href="auditinformation.php?aid='.$audit['auditid'].'"><i class="far fa-question-circle m-r-5"></i> Info</a>';
			$audit_start_date=$audit['start_date'];
			$audit_end_date=$audit['end_date'];
			if($audit_start_date==null || $audit_start_date==''){$audit_start_date='-';}else{$audit_start_date=date('d-m-Y',strtotime($audit_start_date));}
			if($audit_end_date==null || $audit_end_date==''){$audit_end_date='-';}else{$audit_end_date=date('d-m-Y',strtotime($audit_end_date));}
			
			// Audit comments`
			$audit_comments=$audit['comments'];
			$audit_comments=readMore_txt($audit_comments,120,$audit['auditid']);
			
			echo '
			<div class="col-12 p-0">
				<div class="profile-widget mb-1 text-left auditdivbg">
					<!--<div class="doctor-img">
						<a class="avatar" href="profile.html"><img alt="" src="assets/img/doctor-thumb-03.jpg"></a>
					</div>-->
					<div class="dropdown profile-action">
						<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
						<div class="dropdown-menu dropdown-menu-right">
							'.$audit_menu.'
						</div>
					</div>
					<h4 class="doctor-name text-ellipsis" style="margin-right:50px;">'.$audit['name'].'</h4>
					<div class="doc-prof mt-1 mb-1" style="margin-right:50px;">'.$audit_comments.'</div>
					<div class="user-country"><i class="fa fa-map-marker-alt text-info"></i> '.get_locations_name($audit['location_id']).'</div>
					<div class="row">
						<div class="col-4 p-0 pt-1">
							<div class="text-center '.$audit_status_color[$audit['status']].'" style="border: 1px dashed #ccc;">
								'.$audit_status[$audit['status']].'
							</div>
						</div>
						<div class="col-4 p-0 pt-1">
							<div class="text-center" style="border: 1px dashed #ccc;">
								'.$audit_start_date.'
							</div>
						</div>
						<div class="col-4 p-0 pt-1">
							<div class="text-center" style="border: 1px dashed #ccc;">
								'.$audit_end_date.'
							</div>
						</div>
					</div>
				</div>
			</div>';
		}
	}
?>
</div>
<!--
	<div class="col-12 p-0">
		<div class="profile-widget">
			<div class="doctor-img">
				<a class="avatar" href="profile.html"><img alt="" src="assets/img/doctor-thumb-03.jpg"></a>
			</div>
			<div class="dropdown profile-action">
				<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
				<div class="dropdown-menu dropdown-menu-right">
					<a class="dropdown-item" href="edit-doctor.html"><i class="fa fa-pencil m-r-5"></i> Edit</a>
					<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_doctor"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
				</div>
			</div>
			<h4 class="doctor-name text-ellipsis"><a href="profile.html">Cristina Groves</a></h4>
			<div class="doc-prof">Gynecologist</div>
			<div class="user-country">
				<i class="fa fa-map-marker"></i> United States, San Francisco
			</div>
		</div>
	</div>
</div>
-->