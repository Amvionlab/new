<div class="row">
<?php
function readMore_txt($story_desc, $pos = 100) {
	if(strlen($story_desc)>$pos){
		$str_to_insert='<span id="dots"></span><span id="readmore" onclick="readmore_txt();return false;">';
		$story_desc = substr($story_desc, 0, $pos) . $str_to_insert . substr($story_desc, $pos);
		$story_desc = $story_desc."</span> <a href=\"#\" onclick=\"readmore_txt();return false;\" id=\"readMoreBtn\">... more</a>";
	}		
	return $story_desc;  
} 

	$audit_status=array('-','On-Going','Not Started','Completed');
	$audit_status_color=array('bg-danger text-white','bg-warning text-white','bg-info text-white','bg-success text-white');
	$sql="SELECT `auditid`, `name`, `comments`, `location_id`, `userid`, `created_date`, `status`,`start_date`, `end_date`, `is_active`, `is_deleted` FROM `audit` WHERE `userid`='".$_SESSION["login_eid"]."' AND `auditid`='".$auditid."'";
	$where=get_useraccess_acl_locations('`location_id`');//Access location based
	$where.=get_is_deleted_condi();//Deleted computers check
	$sql=$sql.$where;
	$sql=$sql." ORDER BY `status`;";
	$audit_locationid='';
	$audit_array=sqlquery($sql);
	$auditcount=sqlnumrow($audit_array);
	
	if($auditcount==0)
	{
		echo nodatafound(70);
	}
	else{
		$show_start_button=true;
		while($audit=sqlarray($audit_array))
		{
			$audit_locationid=$audit['location_id'];
			$audit_by=$audit['userid'];
			//2-not start, 1-started, 3-completed
			$i=$audit['status'];
			$bgclass='bg-black ';
			if($i==1){$bgclass='bg-orange ';}
			elseif($i==2){$bgclass='bg-white ';}
			$audit_menu='';
			if($i==1 || $i==3){ 
				$audit_menu.='<a class="dropdown-item" href="auditview.php?aid='.$audit['auditid'].'"><i class="fas fa-sitemap m-r-5"></i> View</a>';
				$show_start_button=false;
			}
			if($i==1){
				$audit_menu.='<a class="dropdown-item" href="auditscan.php?aid='.$audit['auditid'].'"><i class="fas fa-barcode m-r-5"></i> Resume Audit</a>';
			}
			$audit_menu.='<a class="dropdown-item" href="auditinformation.php?aid='.$audit['auditid'].'"><i class="far fa-question-circle m-r-5"></i> Info</a>';
			$audit_start_date=$audit['start_date'];
			$audit_end_date=$audit['end_date'];
			if($audit_start_date==null || $audit_start_date==''){$audit_start_date='-';}else{$audit_start_date=date('d-m-Y',strtotime($audit_start_date));}
			if($audit_end_date==null || $audit_end_date==''){$audit_end_date='-';}else{$audit_end_date=date('d-m-Y',strtotime($audit_end_date));}
			
			// Audit comments`
			$audit_comments=$audit['comments'];
			$audit_comments=readMore_txt($audit_comments,120);
			
			/// Total Asset to audit script //

				$sql_con='1';
				$sql_con.=get_dontshowondashboard_condi('status_id');
				$sql_con.=get_is_deleted_condi();//Deleted computers check
				$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
				$where_sql='';
				$where_sql.= " AND `locations_id`= '".$audit_locationid."'";
				$where_sql=$sql_con.$where_sql;
				$totalassetcount=0;
				// For Asset Count
				$sql="SELECT `custom_asset_types`.`gid`,`custom_asset_types`.`catid`, `custom_asset_types`.`name` FROM `custom_asset_types`, `custom_cat_groups` WHERE  `custom_asset_types`.`active`=1 and `custom_asset_types`.`is_deleted`=0 AND `custom_asset_types`.`gid`= `custom_cat_groups`.`gid` AND `custom_cat_groups`.`active`=1 AND `custom_cat_groups`.`is_deleted`=0";
				$customasset_array=sqlquery($sql);
				while($customasset_data=sqlarray($customasset_array))
				{
					$customasset_tablename='customasset_'.$customasset_data['catid'];
					$custom_query_insert='';
					
					// For asset by catid
					$sql="SELECT count(`id`) as `total` FROM `".$customasset_tablename."` WHERE ".$where_sql.";";
					$asset_data=sqlarray(sqlquery($sql));
					$totalassetcount=$totalassetcount+$asset_data['total'];
				}
			//////////////////////////////////

			echo '
			<div class="col-12 p-0">
				<div class="profile-widget mb-0 text-left auditdivbg">
					<!--<div class="doctor-img">
						<a class="avatar" href="profile.html"><img alt="" src="assets/img/doctor-thumb-03.jpg"></a>
					</div>-->
					<div class="dropdown profile-action">
						<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
						<div class="dropdown-menu dropdown-menu-right">
							'.$audit_menu.'
						</div>
					</div>
					<h4 class="doctor-name text-ellipsis" style="margin-right:50px;">'.$audit['name'].'</h4>
					<div class="doc-prof mt-1 mb-1" style="margin-right:50px;">'.$audit_comments.'</div>
					<div class="user-country">Total asset`s: <font class="text-info">'.$totalassetcount.'</font></div>
					<div class="user-country pt-1 pb-1"><i class="fa fa-map-marker-alt text-info"></i> '.get_locations_name($audit['location_id']).'</div>
					<div class="row">
						<div class="col-4 p-0 pt-1">
							<div class="text-center '.$audit_status_color[$audit['status']].'" style="border: 1px dashed #ccc;">
								'.$audit_status[$audit['status']].'
							</div>
						</div>
						<div class="col-4 p-0 pt-1">
							<div class="text-center" style="border: 1px dashed #ccc;">
								'.$audit_start_date.'
							</div>
						</div>
						<div class="col-4 p-0 pt-1">
							<div class="text-center" style="border: 1px dashed #ccc;">
								'.$audit_end_date.'
							</div>
						</div>
					</div>
				</div>
			</div>';
		}
	}
		
	$userid=$audit_by;
	echo '<div class="col-md-12 p-0 m-0">';
			include_once("auditby.php");
	echo '</div>
	';
?>
</div>