<html>
<head></head>
<body style="background-color:#A8E2D4">
<?php echo $hrml_summary;?>
<center><h3 style="color:#fff;">How to scan?</h3></center>
<img src="../../assets/img/audit_scan_process.jpg" width="100%">
<center><h4 style="color:#fff;">Audit scan success</h4>
<img src="../../assets/img/audit_scan_success.jpg" width="50%">
</center>

<p></p>
</body>
</html>