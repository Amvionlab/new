<?php
$scanned_list_html='';
/*
$sql_con='1';
$sql_con.=get_dontshowondashboard_condi('status_id');
$sql_con.=get_is_deleted_condi();//Deleted computers check
$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
$where_sql='';
$where_sql.= " AND `locations_id`= '".$audit_locationid."'";
$where_sql=$sql_con.$where_sql;
*/
$total_scanned=$total_pending=$total_error=$audit_total=0;
$overall_asset_count=$totalassetcount;
//Audit Table
$sql="SELECT count(`id`) as `total` FROM `audit_asset_list` WHERE `aid`=".$auditid." AND `is_error`=0;";
$customasset_count=sqlarray(sqlquery($sql));
$total_scanned=$customasset_count['total'];	

$sql="SELECT count(`id`) as `total` FROM `audit_asset_list` WHERE `aid`=".$auditid." AND `is_error`=1;";
$customasset_count=sqlarray(sqlquery($sql));
$total_error=$customasset_count['total'];	

$sql="SELECT `id`, `aid`, `audit_scan_date`, `audit_by`, `asset_id`, `db_table_name`, `name`, `tag`, `comment`, `serial`, `otherserial`, `locations_id`, `type_id`, `model_id`, `manufacturers_id`, `default_1`, `default_2`, `is_deleted`, `employee_id`, `status_id`, `substatus_id`, `date_creation`, `created_login`, `is_update_type`, `add_type`, `date_mod`, `mod_login`, `is_allocated`, `is_duplicate`, `is_error`, `error_hint` FROM `audit_asset_list` WHERE `aid`=".$auditid." ORDER BY `id` DESC LIMIT 10;";
$audit_scan_list_array=sqlquery($sql);
while($audit_asset_list=sqlarray($audit_scan_list_array))
{
	// url for asset ////////
	$url='#';
	$catid=0;
	if(isset($audit_asset_list['tag']) && $audit_asset_list['tag']<>'')
	{
		$tag=$audit_asset_list['tag'];
		$ref_code = substr($tag, 0, 6);
		$sql="SELECT `custom_asset_id`,`db_table_name` FROM `assettag_config` WHERE `ref_code`='".$ref_code."' LIMIT 1;";
		$tablename_array=sqlarray(sqlquery($sql));
		if(isset($tablename_array['db_table_name']))
		{
			$tablename=$tablename_array['db_table_name'];
			// Need to find gid,catid,id
			$sql="SELECT `id` FROM `".$tablename."` WHERE `tag`='".$tag."' ";
			$sql.=get_is_deleted_condi();//Deleted computers check
			//$sql.=get_useraccess_acl_locations('`locations_id`');//Access location based
			$sql.=" LIMIT 1;";	
			$id_array=sqlquery($sql);
			$count=sqlnumrow($id_array);
			if($count==1)
			{
				$asset_id=sqlarray($id_array);
				// Find gid & catid using `custom_asset_id` from `assettag_config`
				$sql="SELECT `catid`, `gid` FROM `custom_asset_types` WHERE `catid`='".$tablename_array['custom_asset_id']."' LIMIT 1;";
				$refid=sqlarray(sqlquery($sql));
				$url="viewasset.php?gid=".$refid['gid']."&catid=".$refid['catid']."&id=".$asset_id['id'];
				$catid=$refid['catid'];
			}
			else{
				$noresult=true;
			}
		}
		else{
			$noresult=true;
		}
	}
	/// Cat image
	$icon_path=$base_dir.'/../img/customasset/'.$catid.'.png';
	$customasset_tablename="customasset_".$catid;
	if(!file_exists($icon_path))
	{
		$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/0.png';
	}
	else{
		$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/'.$catid.'.png';
	}
	// Asset image
	$img='';
	$sql="SELECT `attachment_id`, `asset_tablename`, `asset_id`, `attachmentname`, `path`, `filetype`, `filesize`, `is_assetimage`, `is_view` FROM `asset_documents` WHERE `asset_tablename`='".$customasset_tablename."' AND `asset_id`='".$audit_asset_list["asset_id"]."' AND `is_assetimage`=1";
	$image_array=sqlquery($sql);
	while($image_data=sqlarray($image_array)){
		$img_type=array('jpg','jpeg','png','gif');
		$img_src_path=$base_dir."/../".$image_data['path'];
		$path_info = pathinfo($img_src_path);
		$file_type=$path_info['extension'];
		if($image_data["is_assetimage"]==1 && in_array($file_type, $img_type))
		{
			$img=ASSET_IMG_BASE_URL.'/'.$image_data['path'];
		}
	}
	if($img==''){$img=$icon_path;}
	/////////////////////////
	// Check for Error msg
	$verified_html='<span class="contact-view text-info pt-2 mt-1" style="font-size:22px"><i class="far fa-check-circle text-success"></i></span>';
	$verified_status_html='<br><font style="font-size:12px;color:green;"><i class="far fa-check-circle m-r-2"></i> Verified</font>';
	if($audit_asset_list['is_error']==1)
	{
		$verified_html='<span class="contact-view text-info pt-2 mt-1" style="font-size:22px"><i class="far fa-times-circle text-danger"></i></span>';
		$verified_status_html='<br><font style="font-size:12px;color:red;"><i class="far fa-times-circle m-r-2"></i> '.$audit_asset_list['error_hint'].'</font>';
	}
	/////////////////////
	$scanned_list_html.='<li class="asset-item p-2" id="'.$audit_asset_list["id"].'">
						<a href="'.BASE_URL.'/'.$url.'" title="'.$audit_asset_list['name'].'">
						<div class="contact-cont">
							<div class="float-left user-img m-r-10">
								<img src="'.$img.'" alt="" class="w-40 rounded" style="max-height:55px;max-width:55px;min-width:auto;">
							</div>
							<div class="row contact-info p-0">
								<div class="col-10 p-0">
								<span class="contact-name text-ellipsis">'.$audit_asset_list['name'].'</span>
								<span class="contact-date text-danger">'.$audit_asset_list["serial"].'</span> | 
								<span class="contact-date text-success">'.strtoupper($tag).'</span><br>
								<span class="contact-date">'.call_custom_asset_manufacturers_name($audit_asset_list["manufacturers_id"]).' | '.call_custom_asset_model_name($audit_asset_list["model_id"]).'</span><br>
								<span class="contact-date"><i class="fa fa-map-marker-alt text-info"></i> '.get_locations_name($audit_asset_list['locations_id']).'</span>
								'.$verified_status_html.'
								</div>
								<div class="col-2 pt-2">'.$verified_html.'</div>
							</div>
						</div>
						</a>
					</li>';
	
}
// For summry
$total_scanned=$total_scanned;
$total_pending=$overall_asset_count-$total_scanned;
$total_error=$total_error;
$hrml_summary='';
$hrml_summary.= '<div class="row p-0 pb-0">
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border: 1px dashed #ccc;">
							Scanned
							<h4 class="text-info">'.$total_scanned.'</h4>
						</div>
					</div>
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border-top: 1px dashed #ccc;border-bottom: 1px dashed #ccc;">
							Pending
							<h4 class="text-warning">'.$total_pending.'</h4>
						</div>
					</div>
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border: 1px dashed #ccc;">
							Error
							<h4 class="text-danger">'.$total_error.'</h4>
						</div>
					</div>
				</div>';
echo '
		<div class="col-12 p-0 m-0">
			<div class="card assetlist-panel m-0">
				<h3 class="card-title pt-3 pl-3 mb-3 pr-3" style="text-transform:uppercase">Scanned as of now</small>
					<span class="badge badge-pill bg-danger float-right"><a href="#" onclick="call_auditscanner('.$auditid.');return false;" style="color:#fff"><i class="fas fa-camera m-r-5"></i> Start Scan</a></span></h3>
				'.$hrml_summary.'
				<div class="card-body">
					<ul class="contact-list" id="asset-list">
						'.$scanned_list_html.'
					</ul>
				</div>
			</div>
		</div>
	';
?>