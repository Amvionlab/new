<?php
$audit_html='';
$sql_con='1';
$sql_con.=get_dontshowondashboard_condi('status_id');
$sql_con.=get_is_deleted_condi();//Deleted computers check
$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
$where_sql='';
$where_sql.= " AND `locations_id`= '".$audit_locationid."'";
$where_sql=$sql_con.$where_sql;

$overall_asset_count=$total_scanned=$total_pending=$total_error=0;

$sql="SELECT `gid`,`name` FROM `custom_cat_groups` WHERE `active`=1 and `is_deleted`=0";
$customgroup_array=sqlquery($sql);

while($customgroup_data=sqlarray($customgroup_array))
{
	$totalassetcount=$audit_total=$audit_error=0;
	$sql="SELECT `catid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `gid`='".$customgroup_data['gid']."'";
	$customasset_array=sqlquery($sql);
	while($customasset_data=sqlarray($customasset_array))
	{
		$customasset_tablename='customasset_'.$customasset_data['catid'];
		$sql="SELECT count(`id`) as `total` FROM `".$customasset_tablename."` WHERE ".$where_sql.";";
		$asset_data=sqlarray(sqlquery($sql));
		$totalassetcount+=$asset_data['total'];
		//Audit Table (success)
		$sql="SELECT count(`id`) as `total` FROM `audit_asset_list` WHERE `db_table_name`='".$customasset_tablename."' AND `aid`=".$auditid." AND `is_error`=0;";
		$customasset_count=sqlarray(sqlquery($sql));
		$audit_total+=$customasset_count['total'];
		//Audit Table (error)
		$sql="SELECT count(`id`) as `total` FROM `audit_asset_list` WHERE `db_table_name`='".$customasset_tablename."' AND `aid`=".$auditid." AND `is_error`=1;";
		$customasset_count=sqlarray(sqlquery($sql));
		$audit_error+=$customasset_count['total'];
		
	}
	$colorclass_null='white';
	$colorclass='warning';
	$img_color='';
	if($audit_total==0)
	{
		$colorclass='danger';
	}
	if($audit_total==$totalassetcount)
	{
		$colorclass='success';
	}
	
	$total_scanned+=$audit_total;
	$total_error+=$audit_error;
	$overall_asset_count+=$totalassetcount;

	$icon_path=ASSET_IMG_BASE_URL.'/img/customasset/gid_'.$customgroup_data['gid'].'.png';
	$audit_html.='<li>
					<a href="auditview.php?aid='.$auditid.'&gid='.$customgroup_data['gid'].'">
						<div class="experience-user">
							<div class="bg-'.$colorclass_null.'" style="border-radius: 	10%;height: 30px;width: 40px;margin-left:-10px;margin-top:-5px">
								<img src="'.$icon_path.'" class="'.$img_color.'" style="width:23px;margin-left:4px;margin-top:3px">
							</div>
						</div>
						<div class="experience-content">
							<div class="timeline-content dash-widget-info">
								<div class="name" style="text-transform:uppercase;color:#313146">'.$customgroup_data['name'].'</div>
								<div style="border-bottom:1px dashed #ccc;display: inline-block;">
									<span>Asset`s <font class="text-info">'.$totalassetcount.'</font></span> - <span><font class="text-'.$colorclass.'">'.$audit_total.'</font> Scanned </span>
								</div>
							</div>
						</div>
					</a>
				  </li>';
}
// For summry
$total_scanned=$total_scanned;
$total_pending=$overall_asset_count-$total_scanned;
$total_error=$total_error;
$hrml_summary='';
$hrml_summary.= '
				<div class="row p-0">
					<!--<div class="col-12 p-0 pt-2">
						<h4><i class="fas fa-barcode fa-flip-horizontal"></i> Scan Summery <i class="fas fa-barcode"></i></h4>
					</div>-->
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border: 1px dashed #ccc;">
							Scanned
							<h4 class="text-info">'.$total_scanned.'</h4>
						</div>
					</div>
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border-top: 1px dashed #ccc;border-bottom: 1px dashed #ccc;">
							Pending
							<h4 class="text-warning">'.$total_pending.'</h4>
						</div>
					</div>
					<div class="col-4 p-0 pt-1">
						<div class="text-center" style="border: 1px dashed #ccc;">
							Error
							<h4 class="text-danger">'.$total_error.'</h4>
						</div>
					</div>
				</div>
				<br>
				';
echo '
	
		<div class="col-12 p-0">
			<div class="card-box m-0">
				<h3 class="card-title" style="text-transform:uppercase">Scanned as of now</h3>
				'.$hrml_summary.'
				<div class="experience-box">
					<ul class="experience-list">
						'.$audit_html.'
					</ul>
				</div>
			</div>
		</div>
	
	';
?>