<?php
//Database connection
	$config_sql_host = "localhost";	// SQL DataBase Server Host Name (or) IP Address
    $config_sql_user = "root";	// SQL DataBase UserName
   	$config_sql_pass = "Root@123";  //Database Password 
	$config_assets_sql_db_name="asset_new"; // Database name
	$config_users_sql_db_name=$config_assets_sql_db_name;
$config_actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http");
define('BASE_URL', 'http://'.$_SERVER['HTTP_HOST'].'/apk');
define('ASSET_IMG_BASE_URL', 'http://'.$_SERVER['HTTP_HOST'].'');
?>
