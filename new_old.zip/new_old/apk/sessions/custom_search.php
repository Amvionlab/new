<?php
include_once('../db/sql.php');
/*
SELECT `id`, `name`, `tag`, `comment`, `serial`, `otherserial`, `locations_id`, `type_id`, `model_id`, `manufacturers_id`, `default_1`, `default_2`, `is_deleted`, `employee_id`, `status_id`, `substatus_id`, `date_creation`, `created_login`, `is_update_type`, `add_type`, `date_mod`, `mod_login`, `is_allocated`, `is_duplicate` FROM `customasset_0` WHERE 1

	[name] => 
    [assettypes_id] => 
    [manufacturers_id] => 
    [models_id] => 
    [serial] => 
    [status_id] => 
    [substatus_id] => 
    [locations_id] => 
    [default_1] => 
    [otherserial] => 
    [default_2] => 
    [comment] => 
	
if(isset($_REQUEST['locationid']))
{
	$_SESSION["search_by_location"]=$locationid;
}*/

$custom_search_query='';
if(isset($_REQUEST))
{
	foreach($_REQUEST as $key => $val)
	{
		$search_key="custom_search_".$key;
		if(trim($val)<>'')
		{
			// Set Session 
			$_SESSION[$search_key]=$val;
			if(trim($custom_search_query)<>''){
				if($key=='comment')
				{
					$custom_search_query.=' AND `'.$key.'`LIKE \'%'.$val.'%\'';
				}else{
					$custom_search_query.=' AND `'.$key.'`=\''.$val.'\'';
				}
			}
			else{
				if($key=='comment')
				{
					$custom_search_query.=' `'.$key.'`LIKE \'%'.$val.'%\'';
				}else{
					$custom_search_query.=' `'.$key.'`=\''.$val.'\'';
				}
			}
		}
		else{
			// Unset null value session
			if(isset($_SESSION[$search_key])){ unset($_SESSION[$search_key]);}
		}
	}
	if(trim($custom_search_query)<>''){
		$_SESSION['custom_search_query']=$custom_search_query;
	}
}

/// Search Query
$gid=$catid='';
if(isset($_REQUEST['group'])){$gid=$_REQUEST['group'];}
if(isset($_REQUEST['cat'])){$catid=$_REQUEST['cat'];}
$search_sql_query='';
$data_found_in_table='';

///// Common for all ////////
$sql_con='1';
$sql_con.=get_dontshowondashboard_condi('status_id');
$sql_con.=get_is_deleted_condi();//Deleted computers check
$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
//////////////////////////////

$sql="SELECT `gid`, `name` FROM `custom_cat_groups` WHERE 1";
if($gid<>''){$sql.=" AND `gid`='".$gid."';";}
$custom_group_array=sqlquery($sql);

while($custom_group_data=sqlarray($custom_group_array))
{
	if($custom_group_data['name']<>''){
		$sql="SELECT `catid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `gid`='".$custom_group_data['gid']."' ORDER BY `name`";
		$template_menu_array=sqlquery($sql);
		while($template_menu_data=sqlarray($template_menu_array))
		{
			$sql="SELECT `mid` FROM `systemadmin_menus` where `menu_mid`=7 AND `menu_order`='".$template_menu_data['catid']."'";
			$mid_value=sqlarray(sqlquery($sql));
			if(isset($mid_value['mid']) && get_acl_access_all_condi($mid_value['mid'])){
				$tablename='customasset_'.$template_menu_data['catid'];
				if($custom_search_query<>''){
					$search_sql_query='SELECT count(`id`) as `total` FROM `'.$tablename.'` WHERE '.$sql_con.' AND '.$custom_search_query.';';
					$sql_total=sqlarray(sqlquery($search_sql_query));
					if($sql_total['total']>0)
					{
						$data_found_in_table.=$tablename.',';
					}
				}
			}
		}
	}
}
if($data_found_in_table<>''){
	$_SESSION['data_found_in_table']=$data_found_in_table;
}else{
	if(isset($_SESSION['data_found_in_table'])) {unset($_SESSION['data_found_in_table']);}
}
$tablenames=explode(',',$data_found_in_table);
$load_html_data='';
$datacount=1;
foreach($tablenames as $key => $val)
{
	if($val<>'')
	{
		//////////////
		$sql="SELECT `id`, `name`, `tag`, `comment`, `serial`, `otherserial`, `locations_id`, `type_id`, `model_id`, `manufacturers_id`, `default_1`, `default_2`, `is_deleted`, `employee_id`, `status_id`, `substatus_id`, `date_creation`, `created_login`, `is_update_type`, `add_type`, `date_mod`, `mod_login`, `is_allocated`, `is_duplicate` FROM `".$val."` WHERE ".$sql_con." AND ".$custom_search_query.";";
		/////////////
		$asset_arraydata=sqlquery($sql);
		// Find Cat & group ID`s
		$cat_id_array=explode('_',$val);
		$cat_id=$cat_id_array[1];
		$sql="SELECT `gid`, `name` FROM `custom_asset_types` WHERE `active`=1 and `is_deleted`=0 and `catid`='".$cat_id."' LIMIT 0,1";
		$groupid_data=sqlarray(sqlquery($sql));
		$group_id=$groupid_data['gid'];
		
		while($asset_data=sqlarray($asset_arraydata))
		{
			// Asset allocation check
			if($asset_data["is_allocated"])
			{
				$allocated_map=get_employees_name($asset_data["employee_id"]);
			}
			else{
				$allocated_map='Not Allocated';
			}
			$tag=$asset_data['tag'];

			$load_html_data.='<tr>
								<td><center>'.$datacount.'</center></td>
								<td><a href="customasset_view.php?group='.$group_id.'&cat='.$cat_id.'&asset='.$asset_data['id'].'">'.strtoupper($tag).'</a></td>
								<td>'.$asset_data['name'].'</td>
								<td>'.call_custom_asset_manufacturers_name($asset_data["manufacturers_id"]).'</td>
								<td>'.call_custom_asset_model_name($asset_data["model_id"]).'</td>
								<td>'.$asset_data["serial"].'</td>
								<td>'.get_locations_name($asset_data["locations_id"]).'</td>
								<td>'.$asset_data["default_1"].'</td>
								<td>'.get_assets_status_name($asset_data["status_id"]).'<br>
									'.get_assets_substatus_name($asset_data["substatus_id"]).'</td>
								<td>'.$allocated_map.'</td>
								<td><center>
									<!--<button class="btn" style="padding:0px;margin:0px;min-width:20px;border:1px;" title="Edit"><i class="fa fa-pencil"></i></button>-->
									<a href="customasset_view.php?group='.$group_id.'&cat='.$cat_id.'&asset='.$asset_data['id'].'"><button class="btn" style="padding:0px;margin:0px;min-width:20px;border:1px;" title="Open"><i class="fa fa-folder-open-o"></i></button></a>
								</center></td>
							  </tr>';
			$datacount++;
		}
	}
}
/*
echo '<pre>';
echo 'My Session ID: '.session_id()."<br>";
echo '$_SESSION'." : ";
print_r($_SESSION);
//echo '$_REQUEST'." : ";
//print_r($_REQUEST);
echo '</pre></div>';
*/

if($load_html_data=='')
{
	echo '<div class="modal-content">
		<div class="modal-header"><button type="button" class="btn btn-sm btn-danger pull-right" aria-label="Close" onclick="call_customsearch();return false;"><span aria-hidden="true"><i class="fa fa fa-search" aria-hidden="true"></i> Search Form</span></button>
		<h4 class="modal-title text-warning text-uppercase" id="myModalLabel">Search Result</h4></div>
		<div class="modal-body"><br><br>'.nodata().'<br><br></div>
	</div>';
}
else{
?>

<div class="modal-content">
	<div class="modal-header"><button type="button" class="btn btn-sm btn-danger pull-right" aria-label="Close" onclick="call_customsearch_reset();return false;"><span aria-hidden="true"><i class="fa fa-refresh" aria-hidden="true"></i> Clear</span></button>
	<h4 class="modal-title text-warning text-uppercase" id="myModalLabel">Search Result</h4></div>
	<div class="modal-body">
		
			<table id="searchtable" class="table stripe cell-border order-column hover compact">
				<thead>
					<tr>
						<th width="">#</th>
						<th width="">Tag</th>	
						<th width="">Name</th>
						<th width="">Manufacturer</th>
						<th width="">Model</th>
						<th width="">Serial Number</th>
						<th width="">Location</th>
						<th width="">Office/CTI</th>
						<th width="">Status</th>
						<th width="">Allocated User</th>
						<?php
							echo'<th width="5%" data-orderable="false" class="dt-no-export">Action</th>';
						?>
					</tr>
				</thead>                               
				<tbody>
					<?php echo $load_html_data;?>
				</tbody>
			</table>
		
	</div>
</div>
<?php } ?>