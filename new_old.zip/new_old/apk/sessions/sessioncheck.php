<?php
$kickmeout=false;
if (session_status() == PHP_SESSION_NONE) {
 session_start();
}
if(!isset($_SESSION["login_eid"]) || trim($_SESSION["login_eid"])=='' || trim($_SESSION["login_eid"])<=0)
{
	$kickmeout=true;
	header("location: logout.php");
}else{
	$loginasid=$_SESSION["login_eid"];
	$Ulog_page=$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$Ulog_pagename=basename($_SERVER['PHP_SELF']);
	employee_log_update($loginasid,$Ulog_pagename,$Ulog_page);
}
?>