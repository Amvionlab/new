<?php
include_once('../db/sql.php');
if(isset($_REQUEST['reset']))
{
	$_SESSION["search_by_location"]=$_SESSION["search_by_status"]=$_SESSION["search_by_substatus"]='';
}
?>