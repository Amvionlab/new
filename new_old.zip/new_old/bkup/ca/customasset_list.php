
<?php
$page_menu_id=$_REQUEST["cat"];
$page_menu_access=get_acl_access_all_condi($page_menu_id);
$page_menu_access_edit=get_acl_access_condi($page_menu_id,'edit');

$ca_group_model_value=array();

$customasset_tablename="customasset_".$_REQUEST['cat'];
$asset_id=1;
$sql="SELECT `gid`,`name` FROM `custom_cat_groups` WHERE `gid`='".$_REQUEST['group']."'";
$group_data=sqlarray(sqlquery($sql));
$sql="SELECT  `name` FROM `custom_asset_types` WHERE `catid`='".$_REQUEST['cat']."' and `gid`='".$_REQUEST['group']."'";
$asset_type_name=sqlarray(sqlquery($sql));

$load_html_data='';
$pagetitle=$asset_type_name['name'];
if(isset($_REQUEST['status'])){
$refname='<a href="customasset_cat_status_summary.php?group='.$_REQUEST['group'].'">'.$group_data['name'].'</a>';
$refname2=''.$asset_type_name['name'].'';
$url='&status';
}else{
$refname='<a href="customasset_cat_dashboard.php?group='.$_REQUEST['group'].'">'.$group_data['name'].'</a>';
$refname2=''.$asset_type_name['name'].'';
$url='';
}
// Common SQL
$sql_con='1';
$sql_con.=get_dontshowondashboard_condi('status_id');
$sql_con.=get_is_deleted_condi();//Deleted computers check
$sql_con.=get_useraccess_acl_locations('`locations_id`');//Access location based
$where_sql='';
//$search_by_location=$search_by_status=$search_by_substatus='';
if($search_by_location<>'')
{
	$where_sql.= " AND `locations_id`= '".$search_by_location."'";
}
if($search_by_status<>'')
{
	$where_sql.= " AND `status_id`= '".$search_by_status."'";
}
if($search_by_substatus<>'')
{
	$where_sql.= " AND `substatus_id`= '".$search_by_substatus."'";
}

$where_sql=$sql_con.$where_sql;
/////////////
//Get Custom fileds
$sql="SELECT `catempid`, `field_name`, `field_type`, `field_length`, `active`, `is_deleted`, `created_date`, `is_default` FROM `custom_asset_templates` WHERE `catid`='".$_REQUEST['cat']."' AND `is_default`=0 AND `active`=1";
$customassettemp_array=sqlquery($sql);
$custom_query_insert="";
while($customassettemp_data=mysqli_fetch_array($customassettemp_array))
{
	$fieldname="field".$customassettemp_data['catempid'];
	$col_exits = sqlquery("select `".$fieldname."` from `".$customasset_tablename."` LIMIT 1");
	if($col_exits){
	
		$custom_query_insert.=", `".$fieldname."`";
	}
}
//////////////
$sql="SELECT `id`, `name`, `tag`, `comment`, `serial`, `otherserial`, `locations_id`, `type_id`, `model_id`, `manufacturers_id`, `default_1`, `default_2`, `default_3`, `is_deleted`, `employee_id`, `status_id`, `substatus_id`, `date_creation`, `created_login`, `is_update_type`, `add_type`, `date_mod`, `mod_login`, `is_allocated`, `is_duplicate` ".$custom_query_insert." FROM `".$customasset_tablename."` WHERE ".$where_sql.";";
/////////////
$asset_arraydata=sqlquery($sql);
$datacount=1;
while($asset_data=sqlarray($asset_arraydata))
{
	// Asset allocation check
	if($asset_data["is_allocated"])
	{
		$allocated_map=get_employees_name($asset_data["employee_id"]);
	}
	else{
		$allocated_map='<a href="#" class="add" onclick="change_map_user(\''.$asset_data['id'].'\',\''.$customasset_tablename.'\');return false;" data-toggle="tooltip" title="Not Allocated">Not Allocated</a>';
	}
	$tag=$asset_data['tag'];

	$load_html_data.='<tr><td><center><input type="hidden" name="transfer[]" id="transferInput" value="">
	<input type="checkbox" id="'.$asset_data["id"].'" name="transfer[]" title="'.$asset_data["id"].'" value="'.$asset_data["id"].'" onclick="handleCheckboxClick(this)"></center></td>
						<td><center>'.$datacount.'</center></td>
						<td><a href="customasset_view.php?group='.$_REQUEST['group'].'&cat='.$_REQUEST['cat'].'&asset='.$asset_data['id'].$url.'">'.strtoupper($tag).'</a></td>
						<td>'.$asset_data['name'].'</td>
						<td>'.call_custom_asset_manufacturers_name($asset_data["manufacturers_id"]).'</td>
						<td>'.call_custom_asset_model_name($asset_data["model_id"]).'</td>
						<td>'.$asset_data["serial"].'</td>
						<td>'.get_locations_name($asset_data["locations_id"]).'</td>
						<td>'.$asset_data["default_1"].'</td>
						<td>'.$asset_data["default_3"].'</td>
						<td>'.get_assets_status_name($asset_data["status_id"]).'<br>
						'.get_assets_substatus_name($asset_data["substatus_id"]).'</td>
						<td>'.$allocated_map.'</td>
						<td><center>';
if($page_menu_access_edit){
							$load_html_data.='<a class="add" onclick="edit_asset_details(\''.$customasset_tablename.'\',\''.$asset_data['id'].'\',\''.$_REQUEST['cat'].'\')"><button class="btn" style="padding:0px;margin:0px;min-width:20px;border:1px;" title="Edit"><i class="fa fa-pencil"></i></button></a>';
}
							$load_html_data.='<a href="customasset_view.php?group='.$_REQUEST['group'].'&cat='.$_REQUEST['cat'].'&asset='.$asset_data['id'].$url.'"><button class="btn" style="padding:0px;margin:0px;min-width:20px;border:1px;" title="Open"><i class="fa fa-folder-open-o"></i></button></a>
						</center></td>
					  </tr>';
	$datacount++;
}
// Set Export file name
$export_file_name=$pagetitle;
?>
<div class="col-lg-12 col-md-12"><!--  style="background:red;padding-top:10px;" -->
	<div class="wrapper" style="padding-top:5px;">
			
			<div class="table-responsive" style="">
<?php echo $customasset_tablename;?>
<?php echo $asset_id;?>
					
								<!--	<a class="add" onclick="add_new_transfer('<?php echo $customasset_tablename;?>','<?php echo $asset_id;?>')"><button type="button" id='transfer' class="btn btn-xs btn-warning btn-clear"> Transfer Now</button></a>  -->
								<a class="add" onclick="transferSelectedItems()"><button type="button" id="transfer" class="btn btn-xs btn-warning btn-clear"> Transfer Now</button></a>         
								
				<table id="mytable" class="table stripe cell-border order-column hover compact">
					<thead>
						<tr>
<th width="">.</th>
                        	<th width="">#</th>
                            <th width="">Tag</th>	
                        	<th width="">Name</th>
                            <th width="">Manufacturer</th>
                            <th width="">Model</th>
                            <th width="">Serial Number</th>
                            <th width="">Location</th>
							<th width="">Office/CTI</th>
							<th width="">Purchase date</th>
							<th width="">Status</th>
                            <th width="">Allocated User</th>
                            <?php
								
                            		echo'<th width="5%" data-orderable="false" class="dt-no-export">Action</th>';
								
							?>
                        </tr>
					</thead>                               
					<tbody>
						<?php echo $load_html_data;?>
					</tbody>
				</table>
			</div>
	</div>
</div>
<script>
var selectedCheckboxes = [];

function handleCheckboxClick(checkbox) {
    if (checkbox.checked) {
        selectedCheckboxes.push(checkbox.value);
    } else {
        var index = selectedCheckboxes.indexOf(checkbox.value);
        if (index !== -1) {
            selectedCheckboxes.splice(index, 1);
        }
    }

	var transferArray = [];
        var checkboxes = document.querySelectorAll('input[name="transfer[]"]:checked');

        for (var i = 0; i < checkboxes.length; i++) {
            transferArray.push(checkboxes[i].value);
        }

        // Update the hidden input field with the updated transferArray
        var transferInput = document.getElementById("transferInput");
        transferInput.value = transferArray.join(',');
    

}

function transferSelectedItems() {
    var selectedItems = [];
    var checkboxes = document.querySelectorAll('input[type="checkbox"][name="transfer[]"]:checked');

    checkboxes.forEach(function (checkbox) {
        selectedItems.push(checkbox.value);
    });

    var customasset_tablename = "<?php echo $customasset_tablename; ?>"; // Get PHP variable
    add_new_transfer(customasset_tablename, selectedCheckboxes.join(",")); // Pass the selected items as a comma-separated string

}


function printSelectedCheckboxes() {
    var resultDiv = document.getElementById("selectedCheckboxesResult");
    resultDiv.innerHTML = "Selected Checkboxes: " + selectedCheckboxes.join(",");
}
</script>
<button onclick="printSelectedCheckboxes()">Print Selected Checkboxes</button>
<div id="selectedCheckboxesResult"></div>
<br><br><br><br>


