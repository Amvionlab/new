<?php 
include_once('breadcrumb.php');
$nowdate=date("d-m-Y");
$html='';
if(!isset($asset_id)){
    $asset_id="";
}

if(isset($asset_id) && $asset_id<>''){

$status=array('Canceled','Approved','Rejected','New','Transferred','Received');
$sub_status=array('By Requester','Ready to Transfer','By Approver','Waiting for Approval','Not reached yet','Transfer Completed');
$status_color=array('default','info','danger','warning','primary','success');
/////////////////////////////////////////////
$html='<div class="col-lg-12 col-md-12" style="padding:0px;"><!--  style="background:red;padding-top:10px;" -->
		<div class="wrapper" style="padding:0px;">
				
				<div class="table-responsive" style="padding:0px;">
					<table id="transfer_table" class="table stripe cell-border order-column hover compact">
						<thead>
							<tr>
								<th style="font-size: 10px;">#</th>
								<th style="font-size: 10px;">tag</th>
								<th style="font-size: 10px;" width="20%">From&nbsp;<font style="color:#EB0000;">&#10132;</font>&nbsp;To</th>
								<th style="font-size: 10px;" width="5%">Request Date</th>
								<th style="font-size: 10px;">Request From</th>
								<th style="font-size: 10px;" width="5%">Requested Date</th>
								<th style="font-size: 10px;" width="5%">Transfer Notes</th>
								<th style="font-size: 10px;">Approved By</th>
								<th style="font-size: 10px;" width="5%">Approved Date</th>
								<th style="font-size: 10px;">Transfer Out By</th>
								<th style="font-size: 10px;" width="5%">Transfer Out Date</th>
								<th style="font-size: 10px;">Received By</th>
								<th style="font-size: 10px;" width="5%">Received Date</th>
								<th style="font-size: 10px;">Status</th>
								<th width="5%" style="font-size: 10px;" data-orderable="false" class="dt-no-export">Action</th>
							</tr>
						</thead>                               
						<tbody>';
$sql="SELECT `atid`, `transfer_date`, `received_date`, `transfer_by`, `approved_by`, `approved_date`, `is_active`, `aid`, `asset_table`, `status`, `received_by`, `transfer_note`, `approval_note`, `transfer_to`, `transfer_from`, `out_by`, `out_date`, `approved_view`, `reject_view`, `approved_view_date`, `reject_view_date`, `requested_date`, `transfer_note` FROM `asset_transfer` WHERE `aid`='".$asset_id."' AND `asset_table`='".$customasset_tablename."' ORDER BY `atid` DESC";
$transfer_array=sqlquery($sql);

	if(sqlnumrow($transfer_array)>0)
	{
		$datacount=1;
		$vendor_details='';
		while($transfer_data=sqlarray($transfer_array)){  
			$transfer_date=$requested_date=$approved_date=$out_date=$received_date='';
			if(isset($transfer_data['transfer_date']) && $transfer_data['transfer_date']<>null && $transfer_data['transfer_date']<>''){
				$transfer_date=date('d-m-Y',strtotime($transfer_data['transfer_date']));
			}
			if(isset($transfer_data['requested_date']) && $transfer_data['requested_date']<>null && $transfer_data['requested_date']<>''){
				$requested_date=date('d-m-Y h:i:s',strtotime($transfer_data['requested_date']));
			}
			if(isset($transfer_data['approved_date']) && $transfer_data['approved_date']<>null && $transfer_data['approved_date']<>''){
				$approved_date=date('d-m-Y h:i:s',strtotime($transfer_data['approved_date']));
			}
			if(isset($transfer_data['out_date']) && $transfer_data['out_date']<>null && $transfer_data['out_date']<>''){
				$out_date=date('d-m-Y h:i:s',strtotime($transfer_data['out_date']));
			}
			if(isset($transfer_data['received_date']) && $transfer_data['received_date']<>null && $transfer_data['received_date']<>''){
				$received_date=date('d-m-Y h:i:s',strtotime($transfer_data['received_date']));
			}
			/// Action button ////
			$action=array('','','','','','');
			//Canceled
			$action[0]='<button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Transfer Now" disabled><i class="fa fa-share"></i></button> <button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Cancel Transfer"><i class="fa fa-close" onclick="call_transfer_cancel(\''.$transfer_data['atid'].'\');return false;"></i></button>';
			//Approved
			$action[1]='<button type="button" class="btn btn-success btn-xs" style="font-size:10px;" title="Transfer Now" onclick="call_transfer_out(\''.$transfer_data['atid'].'\');return false;"><i class="fa fa-share"></i></button> <button type="button" class="btn btn-warning btn-xs" style="font-size:10px;" title="Cancel Transfer"><i class="fa fa-close" onclick="call_transfer_cancel(\''.$transfer_data['atid'].'\');return false;"></i></button>';
			//Rejected
			$action[2]='<button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Transfer Now" disabled><i class="fa fa-share"></i></button> <button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Cancel Transfer"><i class="fa fa-close" onclick="call_transfer_cancel(\''.$transfer_data['atid'].'\');return false;"></i></button>';
			//New
			$action[3]='<button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Transfer Now" disabled><i class="fa fa-share"></i></button> <button type="button" class="btn btn-warning btn-xs" style="font-size:10px;" title="Cancel Transfer" onclick="call_transfer_cancel(\''.$transfer_data['atid'].'\');return false;"><i class="fa fa-close"></i></button>';
			//Transferred
			$action[4]='<button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Transfer Now" disabled><i class="fa fa-share"></i></button> <button type="button" class="btn btn-warning btn-xs" style="font-size:10px;" title="Cancel Transfer" onclick="call_transfer_cancel(\''.$transfer_data['atid'].'\');return false;"><i class="fa fa-close"></i></button>';
			//Received
			$action[5]='<button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Transfer Now" disabled><i class="fa fa-share"></i></button> <button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Cancel Transfer"><i class="fa fa-close" onclick="call_transfer_cancel(\''.$transfer_data['atid'].'\');return false;"></i></button>';
			//// ./ button end ///
			$html.='<tr>
						<td><center>'.$datacount.'</center></td>
						<td>#TRA'.$transfer_data['atid'].'</td>
						<td>'.get_locations_name($transfer_data['transfer_from']).'&nbsp;<font style="color:#EB0000;">&#10132;</font>&nbsp;'.get_locations_name($transfer_data['transfer_to']).'</td>
						<td>'.$transfer_date.'</td>
						<td>'.get_employee_name($transfer_data['transfer_by']).'</td>												
						<td>'.$requested_date.'</td>
						<td>'.$transfer_data['transfer_note'].'</td>
						<td>'.get_employee_name($transfer_data['approved_by']).'</td>
						<td>'.$approved_date.'</td>
						<td>'.get_employee_name($transfer_data['out_by']).'</td>
						<td>'.$out_date.'</td>
						<td>'.get_employee_name($transfer_data['received_by']).'</td>
						<td>'.$received_date.'</td>
						<td class="text-center"><span class="label label-'.$status_color[$transfer_data['status']].'">'.$status[$transfer_data['status']].'</span><br><small>'.$sub_status[$transfer_data['status']].'</small></td>
						<td class="text-center"><small>'.$action[$transfer_data['status']].'</small></td>
						';
			$datacount++;
		}
		$html.='</tbody></table></div></div></div>';
	}
	else{
		$html=nodata();
	}
}else{
	$html=nodata();
}
?>
 <!-- email template -->
                        <div class="dev-email">
                            <!-- email navigation -->
                            <div class="dev-email-navigation">
                                
                                <?php 
									$menu_detials=$menu_user=$menu_lifecycle=$menu_log=$menu_connection=$menu_transfer=$menu_temptransfer=$menu_warranty=$menu_amc=$menu_documents=$menu_sap='';
									// Set Export file name
									$export_file_name='Transfer_list'.$bradcumb_export_file_name;
									// Set active menu page
									$menu_transfer='class="active"';
									include_once('left_menu.php');
								?>
                                
                            </div>
                            <!-- ./email navigation -->
                            
                            <!-- email message -->
                            <div class="dev-email-message">
                                <!-- <div class="dev-email-message-title"></div>-->
								<div class="dev-email-message-from text-danger" style="font-size:13px;">
								   <?php echo '<i class="fa fa-share"></i> '.strtoupper('Transfer');?>
                                                                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo '<a href="#a">'.strtoupper('Goto Temp Transfer');?>
								</div>
                                <div class="dev-email-message-date">
                                    <a class="tooltipfunction" data-title='Asset Details' data-content='<?php echo $assetdetailspopup;?>'><button type="button" class="btn btn-xs btn-info btn-clear"><i class="fa fa-copy"></i> Asset details</button></a>
									
									<a class="add" onclick="add_new_transfer('<?php echo $customasset_tablename;?>','<?php echo $asset_id;?>')"><button type="button" id='transfer' class="btn btn-xs btn-warning btn-clear"> Transfer Now</button></a>
                                </div>
                                <div class="dev-email-message-text" style="padding-top:0px;font-size:12px;">
									
									<?php echo $html; ?>
									
                                </div>
				


<?php 
include_once('breadcrumb.php');
$nowdate=date("d-m-Y");
$html1='';
if(!isset($asset_id)){
    $asset_id="";
}
if(isset($asset_id) && $asset_id<>''){
$status=array('','Out','Received','','','');
//$sub_status=array('(','','(By Approver)','(Waiting for Approval)','(Yet to reach)','(Transfer Completed)');
$status_color=array('default','primary','success','','','');
	////////////////////////////////////////////
$html1='<div class="col-lg-12 col-md-12" style="padding:0px;"><!--  style="background:red;padding-top:10px;" -->
		<div class="wrapper" style="padding:0px;">
				
				<div class="table-responsive" style="padding:0px;">
					<table id="transfer_table" class="table stripe cell-border order-column hover compact">
						<thead>
							<tr>
								<th style="font-size: 10px;">#</th>
								<th style="font-size: 10px;">tag</th>
								<th style="font-size: 10px;" width="5%">Given To</th>
								<th style="font-size: 10px;" width="20%">Date From&nbsp;<font style="color:#EB0000;">&#10132;</font>&nbsp;To</th>
								<th style="font-size: 10px;" width="5%">Given Days</th>
								<th style="font-size: 10px;">Transfer By</th>
								<th style="font-size: 10px;" width="5%">Transfer Date</th>
								<th style="font-size: 10px;">Received By</th>
								<th style="font-size: 10px;" width="5%">Received Date</th>
								<th style="font-size: 10px;" width="5%">In days</th>
								<th style="font-size: 10px;">Status</th>
								<th width="5%" style="font-size: 10px;" data-orderable="false" class="dt-no-export">Action</th>
							</tr>
						</thead>                               
						<tbody>';
$sql="SELECT `atid`, `from_date`, `to_date`, `given_to`, `givento_type`, `transfer_by`, `transfer_date`, `approved_by`, `approved_date`, `is_active`, `aid`, `asset_table`, `status`, `received_by`, `transfer_note`, `return_note`, `return_date` FROM `temp_transfer`";
$sql=$sql." WHERE `aid`='".$asset_id."' AND `asset_table`='".$customasset_tablename."' AND `transfer_by`='".$loginasid."' ORDER BY `atid` DESC";
$transfer_array=sqlquery($sql);
$datacount=sqlnumrow($transfer_array);
	if($datacount>0)
	{
		$datacount=1;
		$user_name='';
		while($transfer_data=sqlarray($transfer_array)){
			$transfer_date=$requested_date=$approved_date=$out_date=$received_date=$user_name='';
			if(isset($transfer_data['transfer_date']) && $transfer_data['transfer_date']<>null && $transfer_data['transfer_date']<>''){
				$transfer_date=date('d-m-Y h:i:s',strtotime($transfer_data['transfer_date']));
			}
			if(isset($transfer_data['from_date']) && $transfer_data['from_date']<>null && $transfer_data['from_date']<>''){
				$from_date=date('d-m-Y',strtotime($transfer_data['from_date']));
			}
			if(isset($transfer_data['to_date']) && $transfer_data['to_date']<>null && $transfer_data['to_date']<>''){
				$to_date=date('d-m-Y',strtotime($transfer_data['to_date']));
			}
			if(isset($transfer_data['return_date']) && $transfer_data['return_date']<>null && $transfer_data['return_date']<>''){
				$return_date=date('d-m-Y h:i:s',strtotime($transfer_data['return_date']));
			}
			
			if($transfer_data['givento_type']=='appuser'){$user_name=get_employee_name($transfer_data['given_to']);$tran_tag='TTUSER';}
			else{$user_name=get_vendor_name($transfer_data['given_to']);$tran_tag='TTAMC';}
			
			$return_date=$gdays=$rdays='';
			
			$datetime1 = date_create($transfer_data["from_date"]); 
			$datetime2 = date_create($transfer_data["to_date"]); 
			// Calculates the difference between DateTime objects 
			$interval = date_diff($datetime1, $datetime2);  
			// Display the result 
			$gdays= $interval->format('%a');
			
			if($transfer_data["status"]==2){
				$datetime1 = date_create($transfer_data["to_date"]); 
				$datetime2 = date_create($transfer_data["return_date"]); 
				// Calculates the difference between DateTime objects 
				$interval = date_diff($datetime1, $datetime2);  
				// Display the result 
				$rdays= $interval->format('%a'); 
			}
			/// Action button ////
			$action=array('','','','','','');
			//Received
			$action[1]='<button type="button" class="btn btn-none btn-xs" style="font-size:10px;" title="Mark as Recived" onclick="call_temptransfer_in(\''.$transfer_data['atid'].'\');return false;"><i class="fa fa-thumbs-up"></i></button>';
			//// ./ button end ///
			$html1.='<tr>
						<td><center>'.$datacount.'</center></td>
						<td>#'.$tran_tag.''.$transfer_data['atid'].'</td>
						<td>'.$user_name.'</td>
						<td>'.$from_date.'&nbsp;<font style="color:#EB0000;">&#10132;</font>&nbsp;'.$to_date.'</td>
						<td>'.$gdays.'</td>
						<td>'.get_employee_name($transfer_data['transfer_by']).'</td>
						<td>'.$transfer_date.'</td>
						<td>'.get_employee_name($transfer_data['received_by']).'</td>
						<td>'.$return_date.'</td>
						<td>'.$rdays.'</td>
						<td class="text-center"><span class="label label-'.$status_color[$transfer_data['status']].'">'.$status[$transfer_data['status']].'</span></small></td>
						<td class="text-center"><small>'.$action[$transfer_data['status']].'</small></td>
						';
			$datacount++;
		}
		$html1.='</tbody></table></div></div></div>';
	}
	else{
		$html1=nodata();
	}
}
else{
	}
?>


<div class="dev-email-message-from text-danger" style="font-size:13px;">
								   <?php echo '<i class="fa fa-share-square"></i> '.strtoupper('Temporary Transfer');?>
								</div>
                                <div class="dev-email-message-date">
                                    <a class="tooltipfunction" data-title='Asset Details' data-content='<?php echo $assetdetailspopup;?>'><button type="button" class="btn btn-xs btn-info btn-clear"><i class="fa fa-copy"></i> Asset details</button></a>
									
									<a class="add" onclick="add_new_temptransfer('<?php echo $customasset_tablename;?>','<?php echo $asset_id;?>');return false;"><button type="button" class="btn btn-xs btn-warning btn-clear"> Transfer Now</button></a>
									
									<a class="add" onclick="add_new_temptransfer_amc('<?php echo $customasset_tablename;?>','<?php echo $asset_id;?>');return false;"><button type="button" class="btn btn-xs btn-warning btn-clear"> AMC Transfer</button></a>
                                </div>
                                <div class="dev-email-message-text" style="padding-top:0px;font-size:12px;" id="a">
									
									<?php echo $html1; ?>
									
                                </div>




                                <!--
                                <div class="dev-email-message-attachment">
                                    <strong>Comments:</strong><br>
                                    <a href="#">s-7552-22.doc</a>, <a href="#">my-photo-12(1).jpg</a>
                                </div>
                                -->
                            </div>
                            <!-- ./email message -->
                        </div>
                        <!-- ./email template --> 


				
						<?php echo $vendor_details;?>