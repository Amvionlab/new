<?php session_start();include_once('db/sql.php');?>
<!DOCTYPE html>
<html lang="en">
    <?php include_once("common/head.php");?>
    <body>
	
        <!-- set loading layer -->
        <div class="dev-page-loading preloader"></div>
        <!-- ./set loading layer -->       
        
        <!-- page wrapper -->
        <div class="dev-page dev-page-sidebar-collapsed">
            
            <!-- page header -->    
            <?php 
				$menu_url_active='assets';
				include_once("common/header.php");
			?>
            <!-- ./page header -->
            
            <!-- page container -->
            <div class="dev-page-container">
            </div>  
            <!-- ./page container -->
            
			<!-- page title -->
			<div class="page-title">
				<div class="col-md-12" style="padding-left:10px;">
					<p id="pagetitle" class="pull-left" style="padding-top:6px;">Page Title</p>
					<?php
					if(isset($_REQUEST['status']))
					{
					echo '<ul class="breadcrumb" style="right:10px">
							<li><a href="."><i class="fa fa-home"></i></a></li>
							<li><a href="customasset_status_summary.php">Status Summery</a></li>
							<li id="refname"></li>
							<li id="refname2"></li>
							<li id="refname3"></li>
						 </ul>';
					}
					elseif(isset($_REQUEST['amc']))
					{
					echo '<ul class="breadcrumb" style="right:10px">
							<li><a href="."><i class="fa fa-home"></i></a></li>
							<li><a href="customasset_amc_summary.php">amc Summery</a></li>
							<li id="refname"></li>
							<li id="refname2"></li>
							<li id="refname3"></li>
						 </ul>';
					}
					else{
					echo '<ul class="breadcrumb" style="right:10px">
							<li><a href="."><i class="fa fa-home"></i></a></li>
							<li><a href=".">Asset Summary</a></li>
							<li id="refname"></li>
							<li id="refname2"></li>
							<li id="refname3"></li>
						 </ul>';
					}
					?>
				</div>
			</div>                        
			<!-- ./page title -->   
						
            <!-- page content -->
                <div class="dev-page-content">                    
                    <!-- page content container -->
                    <div class="container">
                                                                   
                       <div class="row row-condensed">
							<?php include_once('modules/customasset/customasset_view_transfer.php');?>
					   </div>
                        
                    </div>
                    <!-- ./page content container -->
                                        
                </div>
                <!-- ./page content -->  
				
				
				<div class="modal fade" id="modal_transfer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog modal-transfer">
						
					</div>
				</div>
            <!-- page footer -->    
            <?php include_once('common/footer.php');?>
            <!-- ./page footer -->
            
            <!-- page search -->
            <div class="dev-search">
                <div class="dev-search-container">
                    <div class="dev-search-form">
                    <form action="index.html" method="post">
                        <div class="dev-search-field">
                            <input type="text" placeholder="Search..." value="Nature">
                        </div>                        
                    </form>
                    </div>
                    <div class="dev-search-results"></div>
                </div>
            </div>
            <!-- page search -->            
        </div>
        <!-- ./page wrapper -->
		<?php if(!isset($export_file_name)){ $export_file_name='DataExport'; } ?>
        <!-- javascript -->
        <?php include_once('common/js.php');?>
		<script type="text/javascript" src="js/dev-email.js"></script>
		<script>
		$(document).ready(function() {
			// For all files
			$("#refname2").html('<?php echo $refname2;?>');
			$("#refname3").html('<?php echo $refname3;?>');
			
			// PopUp
			Tipped.create('.tooltipfunction', function(element) {
			  return {
				title: $(element).data('title'),
				content: $(element).data('content')
			  };
			}, {
			  skin: 'light'
			});
			
			var table=$('#transfer_table').DataTable( {
				dom: 'Bfrtip',
				pageLength: <?php echo $config_list_page_cnt;?>,
				autoWidth: true,
				fixedHeader: { headerOffset: 40 },
				paging: true,
				ordering: true,
				info:     true,
				buttons: [
					'copy', 
					{
						extend: 'csv',
						title: '<?php echo $export_file_name;?>',
						messageTop: 'The information in this table is copyright to Sirius Cybernetics Corp.'
					}, 
					{
						extend: 'excel',
						title: '<?php echo $export_file_name;?>',
						messageTop: 'The information in this table is copyright to Sirius Cybernetics Corp.',
					}, 
					{
						extend: 'pdf', 
						title: '<?php echo $export_file_name;?>',
						orientation: 'landscape',
						pageSize: 'LEGAL',
						//text:'<i class="fa fa-fw fa-file-pdf-o" style="color:#900;"></i> <i class="fa fa-fw fa-download" style="color:#900;"></i>'
					},
					'print'
				],
				language: { emptyTable : '<?php echo nodata(20);?>'}
				 //stateSave: true
				 
			} );
		});
		
		// View vendor details
		viewVendor_Details=function(model_content)
		{
			$('.modal-vendor').html(model_content);
			$('#modal_vendor').modal({
				backdrop: 'static',
				keyboard: false
			});
			
			dev_forms.init();
		}
		
		// For add warrnty form
		add_new_transfer=function(customasset_tablename,asset_id)
		{
			
			$.get("modalpage/transfer_add.php?customasset_tablename="+customasset_tablename+"&asset_id="+asset_id, function(data, status){
				//alert(data);
				$('.modal-transfer').html(data);
				$('#modal_transfer').modal({
					backdrop: 'static',
					keyboard: false
				});
				$('#transferdate').datetimepicker({
					format: 'MM/DD/YYYY'
				});
				dev_forms.init();
			});
			
		}
		
		// Add amc
		submit_transfer_add1=function()
		{
			console.log( $('#asset_transfer_form').serialize());			
			$.ajax({
				url: 'querys/insert_transfer.php',
				type: 'POST',
				data: $('#asset_transfer_form').serialize(),
				success: function(data) {
					if(data=='error:session_expired')
					{
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Success",   
							text: "Transfer request added successfully.",   
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to add transfer request."+data, "error");
						$("#modal_transfer").modal('show');
					}
				}
			});
		}
		
		// Add amc
		submit_amc_edit=function()
		{
			$.ajax({
				url: 'querys/update_amc.php',
				type: 'POST',
				data: $('#asset_amc_form').serialize(),
				success: function(data) {
					if(data=='error:session_expired')
					{
						$("#modal_amc").modal('hide');
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						$("#modal_amc").modal('hide');
						swal({   
							title: "Success",   
							text: "AMC details updated successfully.",
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to update amc details.", "error");
						$("#modal_amc").modal('show');
					}
				}
			});
		}
		
		// Delete confirmation
		function delete_amc_details(amcid)
		{
				
			swal({   
			title: "AMC details deleted permanently!",   
			text: "Are you sure to proceed?",   
			type: "warning",
			showCancelButton: true,   
			confirmButtonColor: "#DD6B55",   
			confirmButtonText: "Yes, Remove!",   
			cancelButtonText: "No, I am not sure!",   
			closeOnConfirm: false,   
			closeOnCancel: true 
			}, 
				function(isConfirm){   
					if (isConfirm){  
						delete_amc(amcid);
					} 
				}
			);
		}

		// Delete AMC
		delete_amc=function(amcid)
		{
			$.ajax({
				url: 'querys/delete_amc.php?amcid='+amcid,
				success: function(data) {
					if(data=='error:session_expired')
					{
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						swal({   
							title: "Success",   
							text: "AMC details removed successfully.",   
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to remove amc details.\n"+data, "error");
					}
				}
			});
		}

//temp
add_new_temptransfer=function(customasset_tablename,asset_id)
		{
			$.get("modalpage/temptransfer_add.php?customasset_tablename="+customasset_tablename+"&asset_id="+asset_id, function(data, status){
				//alert(data);
				$('.modal-transfer').html(data);
				$('#modal_transfer').modal({
					backdrop: 'static',
					keyboard: false
				});
				
					$('#fromdate,#todate').datetimepicker({
						useCurrent: false,
						minDate: moment()
					});
					$('#fromdate').datetimepicker().on('dp.change', function (e) {
						var incrementDay = moment(new Date(e.date));
						incrementDay.add(1, 'days');
						$('#todate').data('DateTimePicker').minDate(incrementDay);
						$(this).data("DateTimePicker").hide();
					});

					$('#todate').datetimepicker().on('dp.change', function (e) {
						var decrementDay = moment(new Date(e.date));
						decrementDay.subtract(1, 'days');
						$('#fromdate').data('DateTimePicker').maxDate(decrementDay);
						 $(this).data("DateTimePicker").hide();
					});
						dev_forms.init();
			});
		}
		
		add_new_temptransfer_amc=function(customasset_tablename,asset_id)
		{
			$.get("modalpage/temptransfer_add.php?customasset_tablename="+customasset_tablename+"&asset_id="+asset_id+"&vendor", function(data, status){
				//alert(data);
				$('.modal-transfer').html(data);
				$('#modal_transfer').modal({
					backdrop: 'static',
					keyboard: false
				});
				
					$('#fromdate,#todate').datetimepicker({
						useCurrent: false,
						minDate: moment()
					});
					$('#fromdate').datetimepicker().on('dp.change', function (e) {
						var incrementDay = moment(new Date(e.date));
						incrementDay.add(1, 'days');
						$('#todate').data('DateTimePicker').minDate(incrementDay);
						$(this).data("DateTimePicker").hide();
					});

					$('#todate').datetimepicker().on('dp.change', function (e) {
						var decrementDay = moment(new Date(e.date));
						decrementDay.subtract(1, 'days');
						$('#fromdate').data('DateTimePicker').maxDate(decrementDay);
						 $(this).data("DateTimePicker").hide();
					});
						dev_forms.init();
			});
		}
		
		submit_transfer_add=function()
		{
			$.ajax({
				url: 'querys/insert_temptransfer.php',
				type: 'POST',
				data: $('#asset_transfer_form').serialize(),
				success: function(data) {
					if(data=='error:session_expired')
					{
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Success",   
							text: "Transfer request added successfully.",   
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to add transfer request."+data, "error");
						$("#modal_transfer").modal('show');
					}
				}
			});
		}
//temp end
		</script>
		
        <!-- ./javascript -->
    </body>
</html>






