<?php session_start();include_once('db/sql.php');?>
<!DOCTYPE html>
<html lang="en">
    <?php include_once("common/head.php");?>
    <body>
	
        <!-- set loading layer -->
        <div class="dev-page-loading preloader"></div>
        <!-- ./set loading layer -->       
        
        <!-- page wrapper -->
        <div class="dev-page dev-page-sidebar-collapsed">
            
            <!-- page header -->    
            <?php 
				$menu_url_active='customassetlist';
				include_once("common/header.php");
			?>
            <!-- ./page header -->
            
            <!-- page container -->
            <div class="dev-page-container">
            </div>  
            <!-- ./page container -->
            
			<!-- page title -->
			<div class="page-title">
				<div class="col-md-12" style="padding-left:10px;">
					<p id="pagetitle" class="pull-left" style="padding-top:6px;">Page Title</p>
					<p id="searchlocation" class="pull-left" style="margin-left:5px;padding-top:6px;"> | <span class="fa fa-map-marker"></span> Location: <a href="#" onclick="call_home_search('modal_default','locationsearch.php');return false;" class="label label-success" style="font-size:10px;">
					<?php
						$search_by_location_name=get_locations_name($search_by_location);
						if($search_by_location_name<>'') {echo $search_by_location_name;} else { echo 'All';}
					?>
					&nbsp; <span class="fa fa-filter"></span></a></p>
					<p id="searchstatus" class="pull-left" style="margin-left:5px;padding-top:6px;"> | <span class="fa fa-flag-o"></span> Status: <a href="#" onclick="call_home_search('modal_default','assetstatus.php');return false;" class="label label-success" style="font-size:10px;">
					<?php
						$search_by_status_name=get_status_name($search_by_status);
						if($search_by_status_name<>'') {echo $search_by_status_name;} else { echo 'All';}
					?>
					&nbsp; <span class="fa fa-filter"></span></a></p>
					<p id="searchsubstatus" class="pull-left" style="margin-left:5px;padding-top:6px;"> | <span class="fa fa-flag-checkered"></span> Sub Status: <a href="#" onclick="call_home_search('modal_default','assetsubstatus.php');return false;" class="label label-success" style="font-size:10px;">
					<?php
						$search_by_substatus_name=get_substatus_name($search_by_substatus);
						if($search_by_substatus_name<>'') {echo $search_by_substatus_name;} else { echo 'All';}
					?>
				</p>
					<?php if($search_by_location=='' && $search_by_status=='' && $search_by_substatus=='') {}else{echo call_filter_reset();} ?>
					
<?php 

					if(isset($_REQUEST['status']))
					{
					echo '<ul class="breadcrumb" style="right:10px">
							<li><a href="."><i class="fa fa-home"></i></a></li>
							<li><a href="customasset_status_summary.php">Status Summery</a></li>
							<li id="refname"></li>
							<li id="refname2"></li>
						 </ul>';
					}else{
					echo '<ul class="breadcrumb" style="right:10px">
							<li><a href="."><i class="fa fa-home"></i></a></li>
							<li><a href=".">Asset Summery</a></li>
							<li id="refname"></li>
							<li id="refname2"></li>
						 </ul>';
					}
					?>
				</div>
			</div>                        
			<!-- ./page title -->   
						
            <!-- page content -->
                <div class="dev-page-content">                    
                    <!-- page content container -->
                    <div class="container">
                                                                   
                       <div class="row row-condensed">


							<?php include_once('modules/customasset/customasset_list.php');?>
					   </div>
                        <?php echo $selectedCheckboxes; ?>
                    </div>
                    <!-- ./page content container -->
                       <div class="modal fade" id="modal_edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg modal-edit">
						
						</div>
					</div>    
                  <div class="modal fade" id="modal_transfer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog modal-transfer">
						
					</div>
				</div>

                </div>
                <!-- ./page content -->  
				
            <!-- page footer -->    
            <?php include_once('common/footer.php');?>
            <!-- ./page footer -->
            
            <!-- page search -->
            <div class="dev-search">
                <div class="dev-search-container">
                    <div class="dev-search-form">
                    <form action="index.html" method="post">
                        <div class="dev-search-field">
                            <input type="text" placeholder="Search..." value="Nature">
                        </div>                        
                    </form>
                    </div>
                    <div class="dev-search-results"></div>
                </div>
            </div>
            <!-- page search -->            
        </div>
        <!-- ./page wrapper -->

        <!-- javascript -->
        <?php include_once('common/js.php');?>
		<script>


		$(document).ready(function() {
			// For all files
			$("#refname2").html('<?php echo $refname2;?>');
			
			 var table=$('#mytable').DataTable( {
				dom: 'Bfrtip',
				pageLength: <?php echo $config_list_page_cnt;?>,
				autoWidth: false,
				fixedHeader: { headerOffset: 40 },
				paging: true,
				buttons: [
					'copy', 
					{
						extend: 'csv',
						title: 'List of <?php echo $export_file_name;?>',
					}, 
					{
						extend: 'excel',
						title: 'List of <?php echo $export_file_name;?>',
					}, 
					{
						extend: 'pdf', 
						title: 'List of <?php echo $export_file_name;?>',
						orientation: 'landscape',
						pageSize: 'LEGAL',
						//text:'<i class="fa fa-fw fa-file-pdf-o" style="color:#900;"></i> <i class="fa fa-fw fa-download" style="color:#900;"></i>'
					},
					'print'
				],
				language: { emptyTable : '<?php echo nodata(20);?>'}
				 //stateSave: true
				 
			} );
			
			//table.search('000001').draw();// Pass value on search
			//table.page( 1 ).draw( false ); // load specified page number
			
		} );
		
// For edit warrnty form
edit_asset_details=function(customasset_tablename,asset_id,catid)
{
	$.get("modalpage/assetdetails_edit.php?customasset_tablename="+customasset_tablename+"&asset_id="+asset_id+"&catid="+catid, function(data, status){
		$('.modal-edit').html(data);
		$('#modal_edit').modal({
			backdrop: 'static',
			keyboard: false
		});
		dev_forms.init();
	});
}
	
// Editcustom asset
submit_asset_edit=function()
{
	$("#modal_loading").modal('show');
	$.ajax({
		url: 'querys/update_customasset.php',
		type: 'POST',
		data: $('#update_customasset_form').serialize(),
		success: function(data) {
			if(data=='error:session_expired')
			{
				$("#modal_loading").modal('hide');
				swal({   
					title: "Session Expired",   
					text: "Your session has expired. Please login again.",   
					type: "error",
					confirmButtonText: "Ok",   
					closeOnConfirm: false
					}, 
						function(isConfirm){   
							if (isConfirm){	
								location.reload();
							}
						}
				);
			}
			else if(data=='error:already_exists'){
				$("#modal_loading").modal('hide');
				swal("Failed", "Give serial number alredy exists", "error");
			}else if(data==true){
				$("#modal_loading").modal('hide');
				swal({   
					title: "Success",   
					text: "Asset details updated successfully.",   
					type: "success",
					confirmButtonText: "Ok",   
					closeOnConfirm: false
					}, 
						function(isConfirm){   
							if (isConfirm){	
								location.reload();
							}
						}
				);
			}else{
				swal("Failed", "Failed to update asset details.", "error");
				$("#modal_loading").modal('hide');
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) { 
			$("#modal_loading").modal('hide');
			swal("Failed", "Failed to update asset details.\n"+errorThrown, "error");
		}  
	});
}


call_substatus_dropdown=function(status_id){
	loadurl = "dropdowns/asset_substatus.php?status_id="+status_id;
	targ='#substatus_id';
	$(targ).html('<option value="">Select</option>');
	$.get(loadurl, function(data) {
		$(targ).html(data);
	});
}


viewVendor_Details=function(model_content)
		{
			$('.modal-vendor').html(model_content);
			$('#modal_vendor').modal({
				backdrop: 'static',
				keyboard: false
			});
			
			dev_forms.init();
		}
		
		// For add warrnty form
		add_new_transfer = function(customasset_tablename, asset_ids, index = 0) {
    if (index < asset_ids.length) {
        // Make a request for the current asset_id
        $.get("modalpage/transfer_add.php?customasset_tablename=" + customasset_tablename + "&asset_id=" + asset_ids[index], function(data, status) {
            // Handle the response for the current asset_id
            $('.modal-transfer').html(data);
            $('#modal_transfer').modal({
                backdrop: 'static',
                keyboard: false
            });
            $('#transferdate').datetimepicker({
                format: 'MM/DD/YYYY'
            });
            dev_forms.init();

            // Call the next iteration with the next index
            add_new_transfer(customasset_tablename, asset_ids, index + 1);
        });

	
    } 
	else {
        // All requests are done, you can perform any final actions here if needed
        console.log("All requests completed");
    }
}


submit_transfer_add1=function()
		{
			console.log( $('#asset_transfer_form').serialize());			
			$.ajax({
				url: 'querys/insert_transfer.php',
				type: 'POST',
				data: $('#asset_transfer_form').serialize(),
				success: function(data) {
					if(data=='error:session_expired')
					{
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Success",   
							text: "Transfer request added successfully.",   
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to add transfer request."+data, "error");
						$("#modal_transfer").modal('show');
					}
				}
			});
		}


	
		// Add amc
		submit_amc_edit=function()
		{
			$.ajax({
				url: 'querys/update_amc.php',
				type: 'POST',
				data: $('#asset_amc_form').serialize(),
				success: function(data) {
					if(data=='error:session_expired')
					{
						$("#modal_amc").modal('hide');
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						$("#modal_amc").modal('hide');
						swal({   
							title: "Success",   
							text: "AMC details updated successfully.",
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to update amc details.", "error");
						$("#modal_amc").modal('show');
					}
				}
			});
		}
		
		// Delete confirmation
		function delete_amc_details(amcid)
		{
				
			swal({   
			title: "AMC details deleted permanently!",   
			text: "Are you sure to proceed?",   
			type: "warning",
			showCancelButton: true,   
			confirmButtonColor: "#DD6B55",   
			confirmButtonText: "Yes, Remove!",   
			cancelButtonText: "No, I am not sure!",   
			closeOnConfirm: false,   
			closeOnCancel: true 
			}, 
				function(isConfirm){   
					if (isConfirm){  
						delete_amc(amcid);
					} 
				}
			);
		}

		// Delete AMC
		delete_amc=function(amcid)
		{
			$.ajax({
				url: 'querys/delete_amc.php?amcid='+amcid,
				success: function(data) {
					if(data=='error:session_expired')
					{
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						swal({   
							title: "Success",   
							text: "AMC details removed successfully.",   
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to remove amc details.\n"+data, "error");
					}
				}
			});
		}

//temp
add_new_temptransfer=function(customasset_tablename,asset_id)
		{
			$.get("modalpage/temptransfer_add.php?customasset_tablename="+customasset_tablename+"&asset_id="+asset_id, function(data, status){
				//alert(data);
				$('.modal-transfer').html(data);
				$('#modal_transfer').modal({
					backdrop: 'static',
					keyboard: false
				});
				
					$('#fromdate,#todate').datetimepicker({
						useCurrent: false,
						minDate: moment()
					});
					$('#fromdate').datetimepicker().on('dp.change', function (e) {
						var incrementDay = moment(new Date(e.date));
						incrementDay.add(1, 'days');
						$('#todate').data('DateTimePicker').minDate(incrementDay);
						$(this).data("DateTimePicker").hide();
					});

					$('#todate').datetimepicker().on('dp.change', function (e) {
						var decrementDay = moment(new Date(e.date));
						decrementDay.subtract(1, 'days');
						$('#fromdate').data('DateTimePicker').maxDate(decrementDay);
						 $(this).data("DateTimePicker").hide();
					});
						dev_forms.init();
			});
		}
		
		add_new_temptransfer_amc=function(customasset_tablename,asset_id)
		{
			$.get("modalpage/temptransfer_add.php?customasset_tablename="+customasset_tablename+"&asset_id="+asset_id+"&vendor", function(data, status){
				//alert(data);
				$('.modal-transfer').html(data);
				$('#modal_transfer').modal({
					backdrop: 'static',
					keyboard: false
				});
				
					$('#fromdate,#todate').datetimepicker({
						useCurrent: false,
						minDate: moment()
					});
					$('#fromdate').datetimepicker().on('dp.change', function (e) {
						var incrementDay = moment(new Date(e.date));
						incrementDay.add(1, 'days');
						$('#todate').data('DateTimePicker').minDate(incrementDay);
						$(this).data("DateTimePicker").hide();
					});

					$('#todate').datetimepicker().on('dp.change', function (e) {
						var decrementDay = moment(new Date(e.date));
						decrementDay.subtract(1, 'days');
						$('#fromdate').data('DateTimePicker').maxDate(decrementDay);
						 $(this).data("DateTimePicker").hide();
					});
						dev_forms.init();
			});
		}
		
		submit_transfer_add=function()
		{
			$.ajax({
				url: 'querys/insert_temptransfer.php',
				type: 'POST',
				data: $('#asset_transfer_form').serialize(),
				success: function(data) {
					if(data=='error:session_expired')
					{
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Session Expired",   
							text: "Your session has expired. Please login again.",   
							type: "error",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else if(data==true){
						$("#modal_transfer").modal('hide');
						swal({   
							title: "Success",   
							text: "Transfer request added successfully.",   
							type: "success",
							confirmButtonText: "Ok",   
							closeOnConfirm: false
							}, 
								function(isConfirm){   
									if (isConfirm){	
										location.reload();
									}
								}
						);
					}else{
						swal("Failed", "Failed to add transfer request."+data, "error");
						$("#modal_transfer").modal('show');
					}
				}
			});
		}
//temp end

function myFunctionInternal() {

var transfer = new Array();
    $.each($("input[name='transfer[]']:checked"), function() {
        transfer.push($(this).val());
    });
    var transfer = new Array();

}





		</script>
		
        <!-- ./javascript -->
    </body>
</html>






